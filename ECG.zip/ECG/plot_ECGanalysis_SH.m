% File: plot_ECGanalysis_SH.m
% Date: 10-MAR-2025; 12-MAR-2025;
%
% Shared version of:
% plot_ECGanalysis.m 24-JUL-2023;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

clear
addpath(genpath('.\'));

workspaceFile = 'wksp_ECGanalysis.mat'; NumFig = 1000;

% load workspace
load(workspaceFile);

% does not work: \$ is interpreted as wrong command
% fprintf(1,[workspaceFile,'\n']);

fprintf(1,'%s \n',workspaceFile);

% transform OUTPUT.ECGanalysis into OUT
if isfield(OUTPUT,'ECGanalysis')
   OUT = OUTPUT.ECGanalysis;
else
   OUT = OUTPUT; 
end

if exist('cycFile','var')
   fprintf(1,'%s \n',cycFile)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% NumFig = 1000;

FigMode = 'subplot';  % 'normal'
printFileType = 'None'; % 'Jpeg';
iAxisFontSize = 12;
iLabelFontSize = 12;
labelType = 2;
printFileFlag = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Npmax = 10^4;
Np = min([Npmax,length(OUT.y.y_t)]); % number of points for signal plot

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fh = figure(NumFig); clf;
set(fh,'Name','ECG and CS signals');

subplot(2,1,1)
plot(OUT.y.y_t(1:Np));
ylabel('y(t)');
xlabel('t/T_s');
title('ECG signal')

subplot(2,1,2)
plot(OUT.x.x_t(1:Np));
ylabel('x(t)');
xlabel('t/T_s');
title('underlying CS signal')

NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fh = figure(NumFig); clf;
set(fh,'Name','periodic and zero-mean CS signals');

subplot(2,1,1)
plot(OUT.x.xp_t(1:Np));
ylabel('x_p(t)');
xlabel('t/T_s');
title('underlying periodic signal')

subplot(2,1,2)
plot(OUT.x.xr_t(1:Np));
ylabel('x_r(t)');
xlabel('t/T_s');
title('underlying zero-mean CS signal')

NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sumModHarm_PSD = OUT.AMTWACS_Estimation.LagProd.OUTPUT_AMTWACS_funcAAD_PSD.sumModHarm_PSD;
F1z = OUT.AMTWACS_Estimation.LagProd.OUTPUT_AMTWACS_funcAAD_PSD.F1;
% sumModHarm_PSD_zoom = OUTPUT.AMTWACS_Estimation.LagProd.OUTPUT_AMTWACS_funcAAD_PSD.sumModHarm_PSD_zoom;
% F1z_zoom = OUTPUT.AMTWACS_Estimation.LagProd.OUTPUT_AMTWACS_funcAAD_PSD.F1_zoom;
Wlpf2 = OUT.AMTWACS_Estimation.LagProd.OUTPUT_AMTWACS_funcAAD_PSD.Wlpf2;
   
Input1.fig_PSDandLPF.DynamicRange_dB = 50;
Input1.fig_PSDandLPF.iAxisFontSize = 12;
 
fh = figure(NumFig); clf;
set(fh,'Name','PSD and LPF');
% if strcmp(FigMode,'subplot')
%    subplot(2,1,1);
% end
            
Input1.fig_PSDandLPF.F1 = F1z;
Input1.fig_PSDandLPF.Wlpf = Wlpf2;
Input1.fig_PSDandLPF.PSD = sumModHarm_PSD;
Input1.fig_PSDandLPF.title_string = 'PSD[y^2(t) e^{-j2\pi\alpha_0 t}] --> PSD[z^{(\alpha_0,W)}(t)]';
        
fig_PSDandLPF(Input1.fig_PSDandLPF);

FigFileName = 'Fig_PSDzat_LagProd';
printFile(FigFileName,printFileType);


NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% epsilon_est_t = OUT.AMTWACS_Estimation.LagProd.epsilon_est_t;
N = length(OUT.y.epsilon_est_t);
tt = (0:1:N-1);

fh = figure(NumFig); clf;
set(fh,'Name','epsilon(t)');
plot(tt,OUT.y.epsilon_est_t,'Linewidth',1,'Color','black');
xlabel('t/T_s','FontSize',12);
ylabel('\epsilon_{est}(t)/T_s','FontSize',12);

FigFileName = 'Fig_epsilonLagProd';
printFile(FigFileName,printFileType);
      
NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a_est_t = OUT.AMTWACS_Estimation.LagProd.a_est_t;

fh = figure(NumFig); clf;
set(fh,'Name','a(t)');
plot(tt,a_est_t,'Linewidth',1,'Color','black');
xlabel('t/T_s','FontSize',12);
ylabel('a_{est}(t)/T_s','FontSize',12);

FigFileName = 'Fig_aLagProd';
printFile(FigFileName,printFileType);
      
NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
Fig1D_Parameters.LogFlag = 0;
Fig1D_Parameters.iAxisFontSize = iAxisFontSize;
Fig1D_Parameters.iLabelFontSize = iLabelFontSize;
Fig1D_Parameters.printFileType = printFileType;
Fig1D_Parameters.printFileFlag = printFileFlag;
Fig1D_Parameters.FigMode = FigMode;
Fig1D_Parameters.labelType = labelType;
Fig1D_Parameters.zoomXAxisFlag = 0;

alpha0 = OUT.x.cycRSCP1.alpha0;
Fig1D_Labels.comment = [' \alpha = ',num2str(alpha0),' f_s'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Fig1D_Labels.title = 'R_x^{(T)}(\alpha,\tau)';
Fig1D_Labels.x = '\tau/T_s';
Fig1D_Parameters.FigID = 'Rxa1zoom';
Fig1D_Parameters.NumFig = NumFig;
Fig1D_Parameters.FigName = 'Rx(alpha0,tau)';
Fig1D_Parameters.LogFlag = 0;

Input1.plotCmplxVectors = []; % reset previous values

Input1.plotCmplxVectors.Z1 = OUT.x.cycRSCP1.Ryxa;
Input1.plotCmplxVectors.xx1 = OUT.x.cycRSCP1.Tau1;
   
plotCmplxVectors(Input1.plotCmplxVectors,Fig1D_Labels,Fig1D_Parameters);
   
NumFig = NumFig+4;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Fig1D_Labels.title = 'S_x^{(T,\Delta f)}(\alpha,f)';
% Fig1D_Labels.x = 'f/f_s';
% Fig1D_Parameters.FigID = 'Sxa1zoom';
% Fig1D_Parameters.NumFig = NumFig;
% Fig1D_Parameters.FigName = 'Sx(alpha0,f)';
% Fig1D_Parameters.LogFlag = 1;
% 
% Input1.plotCmplxVectors = []; % reset previous values
% 
% Input1.plotCmplxVectors.Z1 = OUT.x.cycRSCP1.Syxa;
% Input1.plotCmplxVectors.xx1 = OUT.x.cycRSCP1.F1;
% 
% plotCmplxVectors(Input1.plotCmplxVectors,Fig1D_Labels,Fig1D_Parameters);
% 
% NumFig = NumFig+4;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check the existence of the field OUT.x.stationary and OUT.y.stationary for compatibility 
% with older versions
if isfield(OUT.x,'stationary')&&isfield(OUT.y,'stationary')

   Fig1D_Labels.comment = ' \alpha = 0';

   Fig1D_Labels.title = 'R_x^{(T)}(0,\tau)  and  R_y^{(T)}(0,\tau)';
   Fig1D_Labels.x = '\tau/T_s';
   Fig1D_Parameters.FigID = 'Ryx01zoom';
   Fig1D_Parameters.NumFig = NumFig;
   Fig1D_Parameters.FigName = 'Rx(0,tau) and Ry(0,tau)';
   Fig1D_Parameters.LogFlag = 0;

   Input1.plotCmplxVectors = []; % reset previous values

   Input1.plotCmplxVectors.Z1 = OUT.x.stationary.cycRSCP1.Ryxa;
   Input1.plotCmplxVectors.xx1 = OUT.x.stationary.cycRSCP1.Tau1;

   Input1.plotCmplxVectors.Z2 = OUT.y.stationary.cycRSCP1.Ryxa;
   Input1.plotCmplxVectors.xx2 = OUT.y.stationary.cycRSCP1.Tau1;

   plotCmplxVectors(Input1.plotCmplxVectors,Fig1D_Labels,Fig1D_Parameters);
   
   NumFig = NumFig+4;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   % Fig1D_Labels.title = 'S_x^{(T,\Delta f)}(0,f)  and  S_y^{(T,\Delta f)}(0,f)';
   % Fig1D_Labels.x = 'f/f_s';
   % Fig1D_Parameters.FigID = 'Syx01zoom';
   % Fig1D_Parameters.NumFig = NumFig;
   % Fig1D_Parameters.FigName = 'Sx(0,f) and Sy(0,f) ';
   % Fig1D_Parameters.LogFlag = 1;
   % 
   % Input1.plotCmplxVectors = []; % reset previous values
   % 
   % Input1.plotCmplxVectors.Z1 = OUT.x.stationary.cycRSCP1.Syxa;
   % Input1.plotCmplxVectors.xx1 = OUT.x.stationary.cycRSCP1.F1;
   % 
   % Input1.plotCmplxVectors.Z2 = OUT.y.stationary.cycRSCP1.Syxa;
   % Input1.plotCmplxVectors.xx2 = OUT.y.stationary.cycRSCP1.F1;
   % 
   % plotCmplxVectors(Input1.plotCmplxVectors,Fig1D_Labels,Fig1D_Parameters);
   % 
   % NumFig = NumFig+4;
 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fh = figure(NumFig); clf;
set(fh,'Name','Fourier Series xp(t)')

Z = OUT.x.FourierSeries.FourierCoefficients;
F = OUT.x.FourierSeries.Harmonics;

subplot(2,1,1);
stem(F,abs(Z));
xlabel('f/f_s');
ylabel('magnitude')
title('Fourier Coefficients of x_p(t)');
subplot(2,1,2);
stem(F,angle(Z));
xlabel('f/f_s');
ylabel('phase')

NumFig = NumFig+1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

run plot_signals
% run plot_error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

