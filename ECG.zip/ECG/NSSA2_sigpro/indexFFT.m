% File: indexFFT.m
% Date: 25-JUL-2020; 26-SEP-2020; 27-APR-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [Ind,ind0] = indexFFT(F,Nfft,sym)
% F    = frequency vector (or multi-dimensional array)
% Nfft = number of FFT points

% default values:
if     (nargin==1); Nfft = length(F); sym = 0; 
elseif (nargin==2); sym = 0;
end

if (sym==0)
   No = 1;
elseif (sym==1)
   if     (rem(Nfft,2)==0); No = Nfft/2+1;          
   elseif (rem(Nfft,2)==1); No = (Nfft-1)/2+1;
   end
end

k = max(floor(abs(F(:))))+1;
Ind = rem(round(F*Nfft)+k*Nfft+sym*No,Nfft)+1; 

if (nargout==2)
   ind0 = No;
end

return
