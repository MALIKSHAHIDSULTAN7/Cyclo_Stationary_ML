% File: cycRSCP1_00.m
% Date: 10-MAR-2025;
%
% Shared version of:
% cycRSCP1_0.m  27-JUL-2023;
% Extracted from:
% cycRSCP1.m  21-APR-2022;
%
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function OUTPUT = cycRSCP1_00(y_t,x_t,INPUT) 

% (Conjugate) Cyclic Cross-Correlogram: estimate of the
% (Conjugate) Cyclic Cross-Correlation. 
% Frequency-Smoothed (Conjugate) Cyclic Cross-Periodogram or
% Time-Smoothed (Conjugate) Cyclic Cross-Periodogram: estimates of the
% (Conjugate) Cyclic Cross-Spectrum.
% F1 = frequency axis
% Tau1 = [tau0-taumax:Deltatau:tau0+taumax]

functionInfo = 'cycRSCP1_0.m 27-JUL-2023';

% default values for missing input parameters
if ~isfield(INPUT,'pf'); INPUT.pf = 1; end
if ~isfield(INPUT,'Mb'); INPUT.Mb = 4; end
if ~isfield(INPUT,'tau0'); INPUT.tau0 = 0; end 
if ~isfield(INPUT,'Deltatau'); INPUT.Deltatau = 1; end 
if ~isfield(INPUT,'dtwindow'); INPUT.dtwindow = 'Rect'; end 
if ~isfield(INPUT,'winsmooth'); INPUT.winsmooth = 'sinc'; end 
% if ~isfield(INPUT,'Nf'); INPUT.Nf = 2*(INPUT.taumax); end 
if ~isfield(INPUT,'Nf'); INPUT.Nf = 2^(nextpow2(2*INPUT.taumax+1)); end 
if ~isfield(INPUT,'coh'); INPUT.coh = 1; end 
if ~isfield(INPUT,'medianMode'); INPUT.medianMode = 0; end
if ~isfield(INPUT,'k_med'); INPUT.k_med = 6; end 
if ~isfield(INPUT,'freq2SmoothMode'); INPUT.freq2SmoothMode = 'odd'; end 

alpha0 = INPUT.alpha0;        % (conjugate) cycle frequency    
oc = INPUT.oc;                % (-1/1) optional complex conjugation;
pf = INPUT.pf;                % zero-paddig factor
Deltaf = INPUT.Deltaf;        % spectral frequency resolution
% Mb = INPUT.Mb;                % overlap block factor (time-smoothing method)
smooth = INPUT.smooth;        % ('time' 'frequency'='frequency1' 'frequency2') smoothing type 
tau0 = INPUT.tau0;            % Tau = (tau0-taumax:Deltatau:tau0+taumax)
taumax = INPUT.taumax;        % Tau = (tau0-taumax:Deltatau:tau0+taumax)
Deltatau = INPUT.Deltatau;    % Tau = (tau0-taumax:Deltatau:tau0+taumax)
Nf = INPUT.Nf;                % pf*Nf = number of points frequency axis (smooth = 'frequency2')
dtwindow = INPUT.dtwindow;    % data tapering window
% winsmooth = INPUT.winsmooth;  % F^(-1)[frequency-smoothing window]
% coh = INPUT.coh;              % (-1/0/1) coherent processing (time smoothing)
% medianMode = INPUT.medianMode;
% k_med = INPUT.k_med;
freq2SmoothMode = INPUT.freq2SmoothMode;  % 'even' or 'odd' if smoothing=='frequency2'

x_t = x_t(:).';       % x_t = row vector (.' = transpose; ' = conjugate transpose)
y_t = y_t(:).';       % y_t = row vector (.' = transpose; ' = conjugate transpose)

Ts = 1;              % sampling period 

% N = length(x_t);     % data-record length

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for compatibility with former calling functions 
if strcmp(smooth,'frequency'); smooth = 'frequency1'; end

% Iyxa = [];  % inizialization: (conjugate) cyclic cross periodogram not computed  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = length(x_t);

% maximum time shift (positive or negative)
shiftmax = max(abs(tau0-taumax),abs(tau0+taumax));
if (shiftmax>floor(N/2)) 
    taumax = -abs(tau0) + floor(N/2)-1;  % to avoid errors
    fprintf(1,'WARNING: set taumax = -abs(tau0)+floor(N/2)-1 \n');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (strcmp(smooth,'frequency2'))
   
   % frequency smoothing
   % [Napolitano 2019, Section 5.4.2]
 
   if     (oc==1);  xc_t = x_t; 
   elseif (oc==-1); xc_t = conj(x_t);
   end
 
   tt = 0:Ts:(N-1)*Ts;                          % time axis
   Tau = (tau0-taumax:Deltatau:tau0+taumax);    % lag axis
   
   Ryxa = zeros(1,length(Tau));

   cs = 1; % cyclic shift
   for itau = 1:length(Tau)
      LagProduct_t = shiftlr(y_t(1:N).*datatap(N,dtwindow),-Tau(itau),cs).*(xc_t(1:N).*datatap(N,dtwindow)); % y(t+tau) x^(*)(t)
      Ryxa(itau) = sum(LagProduct_t.*exp(-2j*pi*alpha0*tt))/(N*Ts); 
   end 
      
   % Ryxa_w = Ryxa.*sinc(Tau*Deltaf); 
   % w = windowdef(winsmooth);
   w = @(t) sinc(t);

   % if (pf*Nf/2>taumax)   % only if Deltatau = 1
   %     Npad = fix(pf*Nf/2-taumax);
   % else    
   %     Npad = 0;
   % end
   if (pf*Nf>length(Tau)) 
       Npad = fix((pf*Nf-length(Tau))/2);
   else    
       Npad = 0;
   end

   if strcmp(freq2SmoothMode,'odd')
      % fprintf(1,'mode even \n');
      % Nfft = pf*Nf+1;
      Ryxa_w = [zeros(1,Npad),Ryxa.*w(Deltaf*(Tau-tau0)),zeros(1,Npad)];
   elseif strcmp(freq2SmoothMode,'even')
      % fprintf(1,'mode odd \n');
      % Nfft = pf*Nf;
      Ryxa_w = [zeros(1,Npad),Ryxa.*w(Deltaf*(Tau-tau0)),zeros(1,Npad-1)];
   end

   Nfft = length(Ryxa_w);
   Syxa = fftshift(fft(ifftshift(Ryxa_w),Nfft))*Ts; 

   % bins frequenze numeriche
   if     rem(Nfft,2)==0;  I1 = (-Nfft/2:1:Nfft/2-1);        % Nfft even   
   elseif rem(Nfft,2)==1;  I1 = (-(Nfft-1)/2:1:(Nfft-1)/2);  % Nfft odd
   end
   F1 = I1/(Nfft*Ts);                 % frequency axis

   % if (Deltatau>1)
   %    Input1.multirate.multirateType = 'decimation';
   %    Input1.multirate.M = Deltatau;
   %    Syxa_decimated = multirate(Syxa,Input1.multirate);
   %    Syxa_decimated = Syxa_decimated*Deltatau;
   %    Next = Nfft - length(Syxa_decimated);
   %    if (rem(Next,2)==0)
   %       Syxa = [zeros(1,Next/2),Syxa_decimated,zeros(1,Next/2)];
   %    elseif (rem(Next,2)==1)
   %       Syxa = [zeros(1,(Next-1)/2),Syxa_decimated,zeros(1,(Next-1)/2+1)];
   %    end
   % end
      
end
    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
% Cyclic cross correlation and cyclic cross-covariance in Tau1=[tau0-taumax:Deltatau:tau0+taumax]
% ind0 = index corresponding to tau=0
if (strcmp(smooth,'frequency1'))
   % Deltatau = 1 
   if     (rem(pf*N,2)==0);   ind0 = pf*N/2+1;            % pf*N even
   elseif (rem(pf*N,2)==1);   ind0 = (pf*N-1)/2+1;        % pf*N odd 
   end    
elseif (strcmp(smooth,'frequency2'))
   % Deltatau >= 1 
   if     (rem(Nfft,2)==0);   ind0 = Nfft/2+1;            % Nfft even
   elseif (rem(Nfft,2)==1);   ind0 = (Nfft-1)/2+1;        % Nfft odd 
   end 
   % lenR = length(Ryxa);
   % if     (rem(lenR,2)==0);   ind0R = lenR/2+1;            % lenR even
   % elseif (rem(lenR,2)==1);   ind0R = (lenR-1)/2+1;        % lenR odd 
   % end    
elseif (strcmp(smooth,'time'))
   % Deltatau = 1 
   ind0 = pf*Nb/2+1; % Nb is even
end


switch smooth
    case{'frequency1','time'}
        if (ind0+tau0+taumax>=2*ind0)||(ind0+tau0-taumax<=0); taumax = ind0-abs(tau0)-2; end % to avoid error
        Tau1 = (tau0-taumax:1:tau0+taumax);   % Deltatau=1
        Ryxa = Ryxa(ind0+Tau1); 
    case{'frequency2'}
        Tau1 = (tau0-taumax:Deltatau:tau0+taumax);
        % Ryxa has the same length of Tau1 
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OUTPUT.Ryxa = Ryxa;     % (conjugate) cyclic cross-correlation
% OUTPUT.Cyxa = Cyxa;   
OUTPUT.Tau1 = Tau1;     % Tau axis
OUTPUT.Syxa = Syxa;    
% OUTPUT.Pyxa = Pyxa;    
OUTPUT.F1 = F1;         % spectral frequency axis
% OUTPUT.Iyxa = Iyxa;     % (conjugate) cyclic cross-periodogram
OUTPUT.alpha0 = alpha0; % (conjugate) cycle frequency
OUTPUT.oc = oc;         % optional complex conjugation
% 
OUTPUT.N = N;
OUTPUT.Deltatau = Deltatau;
OUTPUT.InputParameters = INPUT;
OUTPUT.functionInfo = functionInfo;

return
