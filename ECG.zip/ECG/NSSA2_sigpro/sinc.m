function Z=sinc(x)
% Date: 09-FEB-2005

Z=ones(size(x));
I=find(abs(x)>eps);
Z(I)=sin(pi*x(I))./(pi*x(I));

return;
