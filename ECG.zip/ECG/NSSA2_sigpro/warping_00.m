% File: warping_00.m
% Date: 10-MAR-2025;
%
% Shared version of:
% warping_0.m 21-APR-2022; 27-APR-2022;
% Extracted from:
% warping.m 27-APR-2022;
%
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [y_t,Y_f] = warping_00(x_t,INPUT)

% Time Warping:      y(t) = x(psi(t)), Y(f) = FFT[y(t)]

N = length(x_t);

% default input values
if ~isfield(INPUT,'cs'); INPUT.cs = 0; end               % no circular shift
if ~isfield(INPUT,'sym'); INPUT.sym = 0; end             % asymmetric
if ~isfield(INPUT,'clipType'); INPUT.clipType = 2; end   % modulo 1 with values in [-1/2,1/2[
if ~isfield(INPUT,'method'); INPUT.method = 13; end      % SINC interpolation, FAST
if ~isfield(INPUT,'D'); INPUT.D = (N-rem(N,2))/2; end  
if ~isfield(INPUT,'delImageFlag'); INPUT.delImageFlag = 1; end  % remove images

warpingType = INPUT.warpingType;   % 'time' 'frequency'
psi = INPUT.psi;                   % time- or frequency-warping function or vector
method = INPUT.method; 
sym = INPUT.sym;                   % (0/1) asymmetric/symmetric axis
% clipType = INPUT.clipType;         % clip type for frequency warping
% D = INPUT.D;
% cs = INPUT.cs;                     % circular-shift flag
% delImageFlag = INPUT.delImageFlag; % (0/1) remove-image flag

x_t = x_t(:).';    % x_t forced to be a row vector   % .' = non conjugate transpose

Ts = 1;            % sampling period

if (strcmp(warpingType,'time'))
   
   if     (sym==0); tt = axisTF('time','asymmetric',N);
   elseif (sym==1); tt = axisTF('time','symmetric',N);
   end
   
   y_t(1:N) = zeros(1,N);
   
   a = whos('psi');
   if strcmp(a.class,'function_handle')
      % psi is a function_handle that must be evaluated in correspondence of the time vector tt(1:N) 
      psi_vec = psi(tt);
   elseif strcmp(a.class,'double')
      % psi is a vector of doubles = samples of psi(tt(1:N)) 
      psi_vec = psi(1:N);
   end
   % psi_vec is double
      
   switch method
       
       case{11}
           % SINC Interpolation Method (time-consuming memory-saving)
           % [Napolitano 2012, Section 7.7.4]
           % y(t) = x(psi(t)) = sum_k x(k)*sinc((psi(t)-k*Ts)/Ts) 
     
           for n = 1:N
              % y_t(n) = sum(x_t(1:N).*sinc(psi(tt(n))-tt)); % x(psi(t)) (psi=function_handle)
              y_t(n) = sum(x_t(1:N).*sinc(psi_vec(n)-tt));  % x(psi(t))
           end
           
       case{12}
           % SINC Interpolation Method (time-saving memory-consuming)
    
           % the vector (n1:n2) can be possibly chosen different from tt(1:N)  
           n1 = tt(1); n2 = tt(end); 
           nt = n1:n2; 
           fs = 1/Ts; nTs = nt*Ts;
           N1 = length(nt); % possibly different from N
    
           % y_t(1:N) = x_t*sinc(fs*ones(N1,1)*(psi(nTs))-nTs'*ones(1,N));     % x(psi(t)) (psi=function_handle)
           y_t(1:N) = x_t*sinc(fs*ones(N1,1)*(psi_vec(1:N1))-nTs.'*ones(1,N)); % x(psi(t))
            
   end

   if     (sym==0);  Y_f = fftshift(fft(y_t));
   elseif (sym==1);  Y_f = symmfft(y_t,-1);
   end    
            
end

return
