% File: axisTF.m
% Date: 25-JUL-2020; 22-APR-2021; 09-SEP-2021;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [x,xo] = axisTF(cType,cSym,N)

if strcmp(cSym,'asymmetric')
   
   if strcmp(cType,'time') 
      x = (0:1:N-1);
   elseif strcmp(cType,'frequency')
      % FFT frequency axis (without fftshift) 
      if     (rem(N,2)==0);  x = [0:1:N/2-1,-N/2:1:-1]/N;         % N even
      elseif (rem(N,2)==1);  x = [0:1:(N-1)/2,-(N-1)/2:1:-1]/N;   % N odd
      end       
   end
   
   if nargout==2
      xo = 1;
   end
   
elseif strcmp(cSym,'symmetric')
   
   if     (rem(N,2)==0); Ind = (-N/2:1:N/2-1);         % N even
   elseif (rem(N,2)==1); Ind = (-(N-1)/2:1:(N-1)/2);   % N odd
   end    
    
   if strcmp(cType,'time')       
      x = Ind;
   elseif strcmp(cType,'frequency')   
      x = Ind/N;
   end
   
   if nargout==2
      if     (rem(N,2)==0); xo = N/2+1;         % N even
      elseif (rem(N,2)==1); xo = (N-1)/2+1;     % N odd
      end    
   end
   
end
    
return