% File: FourierSeries.m
% Date: 09-MAY-2022--10-MAY-2022; 10-JUL-2022;

function [Z,F,OUTPUT] = FourierSeries(x_t,INPUT)

% Fourier Series of x_t
% if INPUT.period is not empty, only harmonics k/T0 are computed;
% if INPUT.period is empty, a DFT is computed
% if INPUT.sym = 0 time axis is asymmetric
% if INPUT.sym = 1 time axis is symmetric

functionInfo = 'FourierSeries.m 10-JUL-2022';

if nargin==1
  INPUT = [];
end

T0 = defaultFieldValue('INPUT','period',[]);        % period
pf = defaultFieldValue('INPUT','paddingFactor',1);  % zero-padding factor
sym = defaultFieldValue('INPUT','sym',0);           % (0/1) symmetric flag 

x_t = x_t(:).';   % row vector

N = length(x_t);

if isempty(T0)||(T0>N/10)

   if (sym==0)
      % zero padding: pf*N FFT points 
      x_t = [x_t,zeros(1,(pf-1)*N)];
      Z = fftshift(fft(x_t))/N;
      F = axisTF('frequency','symmetric',pf*N);
   elseif (sym==1)
      if rem(N,2)==0
         % zero padding: pf*N FFT points 
         x_t = [zeros(1,(pf-1)*N/2),x_t,zeros(1,(pf-1)*N/2)]; 
         F = axisTF('frequency','symmetric',pf*N);
      elseif rem(N,2)==1
         % zero padding: pf*(N-1)+1 FFT points
         x_t = [zeros(1,(pf-1)*(N-1)/2),x_t,zeros(1,(pf-1)*(N-1)/2)]; 
         F = axisTF('frequency','symmetric',pf*(N-1)+1);
      end
      Z = symmfft(x_t,-1)/N;
   end

else

   if     (sym==0);  tt = axisTF('time','asymmetric',pf*N);
   elseif (sym==1);  tt = axisTF('time','symmetric',pf*N);
   end

   numberHarmonics = fix(T0/2);
   Z = zeros(1,2*numberHarmonics+1);
   for k = -numberHarmonics:1:numberHarmonics
       Z(numberHarmonics+1+k) = sum(x_t.*exp(-2j*pi*(k/T0)*tt))/N;
   end
   F = (-numberHarmonics:1:numberHarmonics)/T0;

end

if nargout==3
    OUTPUT.functionInfo = functionInfo;
    OUTPUT.InputParameters = INPUT;
end

return
