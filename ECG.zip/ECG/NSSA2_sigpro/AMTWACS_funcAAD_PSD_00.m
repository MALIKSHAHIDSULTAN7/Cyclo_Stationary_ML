% File: AMTWACS_funcAAD_PSD_00.m
% Date: 10-MAR-2025;
%
% Shared version of:
% AMTWACS_funcAAD_PSD_0.m 22-APR-2022;
% Modified version of:
% AMTWACS_funcAAD_PSD.m
% 20-APR-2022;
%
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [OUTPUT] = AMTWACS_funcAAD_PSD_00(sumModHarm_t,INPUT)
     
alpha0til = INPUT.alpha0til;
Wlpf = INPUT.Wlpf;

% N = INPUT.N;
N = length(sumModHarm_t);

Deltaf = INPUT.Deltaf;
tau0 = INPUT.tau0;
taumax = INPUT.taumax;
nu_a = INPUT.nu_a;
nu_b = INPUT.nu_b;
k_med = INPUT.k_med;

Ts = 1;  % sampling period

sumModHarmAlpha0_t = sumModHarm_t.*exp(-2j*pi*alpha0til*(0:N-1)*Ts);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

INPUT_cycRSCP1.alpha0 = 0;                 % (conjugate) cycle frequency    
INPUT_cycRSCP1.oc = -1;                    % (-1/1) optional complex conjugation;
INPUT_cycRSCP1.pf = 1;                     % paddig factor
INPUT_cycRSCP1.Deltaf = Deltaf;            % spectral frequency resolution
INPUT_cycRSCP1.Mb = 4;                     % overlap block factor (time-smoothing method)
INPUT_cycRSCP1.smooth = 'frequency2';       % ('time' frequency'='frequency1' 'frequency2') smoothing type 
INPUT_cycRSCP1.Nf = 2^(10);                % pf*Nf number of points of the frequency axis (smooth = 'frequency2')
INPUT_cycRSCP1.freq2SmoothMode = 'odd';       % 'odd' or 'even' for smooth=='frequency2'
INPUT_cycRSCP1.tau0 = tau0;                % tau in [tau0-taumax,tau0+taumax] to compute FT[Ryxa]
INPUT_cycRSCP1.taumax = taumax;            % tau in [tau0-taumax,tau0+taumax] to compute FT[Ryxa]
INPUT_cycRSCP1.dtwindow = 'Rect';          % data tapering window
INPUT_cycRSCP1.winsmooth = 'sinc';         % F^(-1)[frequency-smoothing window]
INPUT_cycRSCP1.medianMode = 0;             % (0,1,2)
INPUT_cycRSCP1.k_med = k_med;

OUTPUT_cycRSCP1 = cycRSCP1_00(sumModHarmAlpha0_t,sumModHarmAlpha0_t,INPUT_cycRSCP1);

% zoom in [nu_a,nu_b)
Input1.zoomAF.fInterval = [nu_a,nu_b];
Input1.zoomAF.Ztype = 'fAxis';
% zoom of monodimensional spectra = zoom of frequency axis
OUTPUT_cycRSCP1.Syxa = zoomAF(OUTPUT_cycRSCP1.Syxa,Input1.zoomAF);
OUTPUT_cycRSCP1.F1 = zoomAF(OUTPUT_cycRSCP1.F1,Input1.zoomAF);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OUTPUT.sumModHarm_PSD = OUTPUT_cycRSCP1.Syxa;
OUTPUT.F1 = OUTPUT_cycRSCP1.F1;
% OUTPUT.sumModHarm_PSD_zoom = OUTPUT_cycRSCP1_zoom.Syxa;
% OUTPUT.F1_zoom = OUTPUT_cycRSCP1_zoom.F1;
OUTPUT.Wlpf2 = Wlpf;

return
     