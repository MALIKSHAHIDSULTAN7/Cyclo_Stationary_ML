% File: AMTWACS_Estimation_00.m
% Date: 10-MAR-2025;
%
% Shared version of:
% AMTWACS_Estimation_0.m 12-JUL-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%
% Extracted from:
% AMTWACS_Estimation.m 12-JUL-2022;

function [OUTPUT] = AMTWACS_Estimation_00(y_t,x_t,INPUT)

% Estimation of the amplitude-modulation function a(t) and 
% the time-warping function epsilon(t) = psi(t) - t of
% an amplitude-modulated time-warped (AM-TW) almost-cyclostationary (ACS) signal:
% y(t) = a(t) x(t+epsilon(t)), x(t) ACS
%
% References:
%
% [Napolitano 2017]
% A. Napolitano "Time-warped almost-cyclostationary signals: Characterization and statistical function
% measurements", IEEE Transactions on Signal Processing, vol. 65, n. 20, pp. 5526-5541, October 15, 2017.
% ISSN: 1053-587X doi: 10.1109/TSP.2017.2728499
%
% [Napolitano 2019]
% A. Napolitano, Cyclostationary Processes and Time Series. Theory, Applications, and Generalizations.
% Elsevier, 2019. ISBN: 9780081027080 doi: 10.1016/C2017-0-04240-4

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% functionInfo = 'AMTWACS_Estimation.m 15-NOV-2021';
% functionInfo = 'AMTWACS_Estimation_0.m 20-APR-2022';
functionInfo = 'AMTWACS_Estimation_0.m 12-JUL-2022';

Ts = 1;
% Signals must have the same length N:
% [x_t,y_t] = sameLength(x_t,y_t,'trunc');      % truncation of the longest signal 
% [x_t,y_t] = sameLength(x_t,y_t,'zeropad');  % zero padding of the shortest signal
N = length(x_t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

twoSteps_flag = INPUT.Parameters.twoSteps_flag;

% 1st step 
% Estimation of a(t), epsilon(t), and alpha0 by amplitude and angle demodulation
% INPUT.AMTWACS_AmplAngDemodZ.funcAAD = 'LagProd';
[a_est_t,epsilon_est_t,OUTPUT_AMTWACS_AmplAngDemodZ] = AMTWACS_AmplAngDemodZ_00(y_t,x_t,INPUT.AMTWACS_AmplAngDemodZ);
STEP1 = OUTPUT_AMTWACS_AmplAngDemodZ;
STEP2 = struct([]);

% PSD of the sum of modulated harmonics
sumModHarm_t = OUTPUT_AMTWACS_AmplAngDemodZ.sumModHarm_t;   
OUTPUT_AMTWACS_funcAAD_PSD = AMTWACS_funcAAD_PSD_00(sumModHarm_t,INPUT.AMTWACS_funcAAD_PSD);

if (twoSteps_flag==1)
   kr = INPUT.Parameters.kr;               % Wlpf = kr*Wlpf at step2
   % 2nd step
   % Estimation of a(t), epsilon(t), and alpha0 by amplitude and angle demodulation
   % update: alpha0til = alpha0est; Wlpf = kr*Wlpf;
   INPUT.AMTWACS_AmplAngDemodZ.alpha0til = OUTPUT_AMTWACS_AmplAngDemodZ.alpha0est;
   INPUT.AMTWACS_AmplAngDemodZ.Wlpf = INPUT.AMTWACS_AmplAngDemodZ.Wlpf*kr;
   [a_est_t,epsilon_est_t,OUTPUT_AMTWACS_AmplAngDemodZ] = AMTWACS_AmplAngDemodZ_00(y_t,x_t,INPUT.AMTWACS_AmplAngDemodZ);
   STEP2 = OUTPUT_AMTWACS_AmplAngDemodZ;
   
   % PSD of the sum of modulated harmonics
   sumModHarm_t = OUTPUT_AMTWACS_AmplAngDemodZ.sumModHarm_t;
   INPUT.AMTWACS_funcAAD_PSD.alpha0til = OUTPUT_AMTWACS_AmplAngDemodZ.alpha0est;
   INPUT.AMTWACS_funcAAD_PSD.Wlpf = INPUT.AMTWACS_funcAAD_PSD.Wlpf*kr;
   OUTPUT_AMTWACS_funcAAD_PSD = AMTWACS_funcAAD_PSD_00(sumModHarm_t,INPUT.AMTWACS_funcAAD_PSD);
end

alpha0est = OUTPUT_AMTWACS_AmplAngDemodZ.alpha0est;
   
% % % parameters for the gradient algorithm
% % INPUT.AMTWACS_maxObjectiveFunction.oc = oc;                  % (-1/1) optional complex conjugation
% INPUT.AMTWACS_maxObjectiveFunction.alphaSet = alpha0est;       % (conjugate) cycle frequency
% % INPUT.AMTWACS_maxObjectiveFunction.tauSet = [Tp/2];          % set of lags
% % INPUT.AMTWACS_maxObjectiveFunction.sym = 0;
% INPUT.AMTWACS_maxObjectiveFunction.a_start = cp;               % starting point
% INPUT.AMTWACS_maxObjectiveFunction.K = length(cp)/2;           % 2*K = number of basis functions
% % INPUT.AMTWACS_maxObjectiveFunction.stepSizeType = 3;         % 3 = step size of Barzilai and Borwein (1988)
% % INPUT.AMTWACS_maxObjectiveFunction.mu_0 = 100000;
% % INPUT.AMTWACS_maxObjectiveFunction.taumu = 0.95;             % 0<taumu<1
% % INPUT.AMTWACS_maxObjectiveFunction.stopCriterion = 4;        % 4 = [Napolitano 2017, Eq. (4.13)]
% % INPUT.AMTWACS_maxObjectiveFunction.eps0 = 10^(-8);           % error
% % INPUT.AMTWACS_maxObjectiveFunction.maxNumIter = 500;         % maximum number of iterations
% 
% % The amplitude and angle demodulation method works with a single pair (alpha0til,tau)
% % and provides the starting point for the gradient-ascent based algorithm.
% % However, the gradient-ascent based algorithm can be implemented to
% % maximize an objective function defined over a 
% % set of values of alpha and a set of values of tau [Napolitano 2017, Eq. (4.8)]

% % Estimation of the coefficients for the expansion of the estimate of epsilon(t) on the
% % basis functions
% [aa_est,OUTPUT_AMTWACS_maxObjectiveFunction] = AMTWACS_maxObjectiveFunction(y_t,x_t,INPUT.AMTWACS_maxObjectiveFunction);
% 
% T0 = N*Ts;
% tt = (0:1:N-1)*Ts;
% K = length(cp)/2;
% 
% % Expansion of the estimate of epsilon(t) by the basis functions with
% % coefficients determined by the gradient algorithm
% epsilon_grad_t = 0;
% for ik = 1:K
%     epsilon_grad_t = epsilon_grad_t + ...
%            aa_est(2*ik-1)*sqrt(2/T0)*cos(2*pi*tt*ik/T0) ...
%          - aa_est(2*ik)*sqrt(2/T0)*sin(2*pi*tt*ik/T0);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OUTPUT.func_AAD = OUTPUT_AMTWACS_AmplAngDemodZ.func_AAD;
OUTPUT.a_est_t = a_est_t;
OUTPUT.epsilon_est_t = epsilon_est_t;
OUTPUT.OUTPUT_AMTWACS_AmplAngDemodZ = OUTPUT_AMTWACS_AmplAngDemodZ;
OUTPUT.OUTPUT_AMTWACS_funcAAD_PSD = OUTPUT_AMTWACS_funcAAD_PSD;

% OUTPUT.epsilon_proj_t = epsilon_proj_t;
% OUTPUT.cp = cp;
% OUTPUT.OUTPUT_projectionFB = OUTPUT_projectionFB;

% OUTPUT.aa_est = aa_est;
% OUTPUT.OUTPUT_AMTWACS_maxObjectiveFunction = OUTPUT_AMTWACS_maxObjectiveFunction;
% 
% OUTPUT.epsilon_grad_t = epsilon_grad_t;

OUTPUT.alpha0est = alpha0est;

% parameters for debug
OUTPUT.twoSteps_flag = twoSteps_flag;
OUTPUT.STEP1 = STEP1;
OUTPUT.STEP2 = STEP2;

OUTPUT.functionInfo = functionInfo;
OUTPUT.InputParameters = INPUT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

return