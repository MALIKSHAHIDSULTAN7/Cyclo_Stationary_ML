% File: estimateAverageHeartRate.m
% Date: 26-APR-2022; 03-JUL-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [Z,OUTPUT] = estimateAverageHeartRate(y_t,INPUT)

functionInfo = 'estimateAverageHeartRate 03-JUL-2022';

ymax = max(y_t);
ymin = min(y_t);
mPP_default = 0.7*(ymax-ymin);

% minPeakProminence = defaultFieldValue('INPUT','minPeakProminence',0.7); % 0.5--0.9
minPeakProminence = defaultFieldValue('INPUT','minPeakProminence',mPP_default); % 0.5--0.9

N = length(y_t);

[pks,loc] = findpeaks(y_t,(0:1:N-1),'MinPeakProminence',minPeakProminence,'Annotate','extents');

% [pks,loc] = findpeaks(y_t,(0:1:length(y_t)-1),'MinPeakDistance',100);

% average heart rate
% [Napolitano 2022, eq. (3.2)]
Z = length(pks)/N;

if nargout==2
   OUTPUT.peakHeights = pks;    % peak heights
   OUTPUT.peakLocations = loc;  % peak locations
   OUTPUT.functionInfo = functionInfo;
   OUTPUT.InputParameters = INPUT;
end

return
