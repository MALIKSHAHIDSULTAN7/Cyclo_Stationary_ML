% File: AMTWACS_AmplAngDemodZ_00.m
% Date: 10-MAR-2025;
%
% Shared version of:
% AMTWACS_AmplAngDemodZ.m 30-APR-2023;
%
function [a_t,epsilon_t,OUTPUT] = AMTWACS_AmplAngDemodZ_00(y1_t,y2_t,INPUT)

% Amplitude and angle demodulation for analysis of 
% an amplitude-modulated time-warped (AM-TW) almost-cyclostationary (ACS) signal:
% y(t) = a(t) x(t+epsilon(t)), x(t) ACS
% References:
%
% [Napolitano 2017]
% A. Napolitano "Time-warped almost-cyclostationary signals: Characterization and statistical function
% measurements", IEEE Transactions on Signal Processing, vol. 65, n. 20, pp. 5526-5541, October 15, 2017.
% ISSN: 1053-587X doi: 10.1109/TSP.2017.2728499
%
% [Napolitano 2019]
% A. Napolitano, Cyclostationary Processes and Time Series. Theory, Applications, and Generalizations.
% Elsevier, 2019. ISBN: 9780081027080 doi: 10.1016/C2017-0-04240-4

functionInfo = 'AMTWACS_AmplAngDemodZ.m 30-APR-2023';

% default values
if ~isfield(INPUT,'oc'); INPUT.oc = -1; end
if ~isfield(INPUT,'sym'); INPUT.sym = 0; end
if ~isfield(INPUT,'knownAlphaFlag'); INPUT.knownAlphaFlag = 0; end
if ~isfield(INPUT,'func_AAD'); INPUT.func_AAD = 'LagProd'; end

if ~isfield(INPUT,'u0')
   switch INPUT.func_AAD
       case{'LagProd'}; INPUT.u0 = 0;
       otherwise
           INPUT.u0 = NaN;
   end
end

oc = INPUT.oc;                           % (-1/1) optional complex conjugation
u0 = INPUT.u0;
sym = INPUT.sym;                         % (0/1) symmetry flag
alpha0til = INPUT.alpha0til;             % (conjugate cycle frequency)
Wlpf = INPUT.Wlpf;                       % monolateral bandwidth of ideal LPF
knownAlphaFlag = INPUT.knownAlphaFlag;
lineEstimationMethod = INPUT.lineEstimationMethod;
func_AAD = INPUT.func_AAD;               % 'LagProd' 'CDF' 'CharFunc' 'Func'

y2_t = y2_t(:).';       % y2_t = row vector (.' = transpose; ' = conjugate transpose)
y1_t = y1_t(:).';       % y1_t = row vector (.' = transpose; ' = conjugate transpose)

Ts = 1;

% Signals must have the same length N:
% [y2_t,y1_t] = sameLength(y2_t,y1_t,'trunc');      % truncation of the longest signal 
% [x_t,y_t] = sameLength(x_t,y_t,'zeropad');  % zero padding of the shortest signal
N = length(y2_t);
T = N*Ts;

if     (sym==0); tt = axisTF('time','asymmetric',N);
elseif (sym==1); tt = axisTF('time','symmetric',N);
end

if     (oc==-1); y2c_t = conj(y2_t);
elseif (oc==1);  y2c_t = y2_t;
end

% sum of amplitude- and angle-modulated harmonics 
switch func_AAD

    case{'LagProd'}
        tau0 = u0;
        cs = 1; % cyclic shift for shiftlr 
        sumModHarm_t = shiftlr(y1_t,-tau0,cs).*y2c_t;   % y1(t+tau0) y2(*)(t)        
    otherwise
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% z^{(W)}(alpha0;t,tau) =
% z(t) = [y1(t+tau) y2(*)(t) exp(-j2 pi alpha0 t)] convolved with  
% h_{LP}(t) = ideal low-pass filtering with monolateral bandwidth Wlpf
% [Napolitano 2019, Eq. (14.53)]
sumModHarm_f = fft(sumModHarm_t.*exp(-2j*pi*alpha0til*tt));
z_f = zeros(1,N);
Ind = indexFFT((-Wlpf:1/N:Wlpf),N);
z_f(Ind) = sumModHarm_f(Ind);
%%% z_t = fftshift(ifft(z_f));
z_t = ifft(z_f);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Estimation of a(t)
switch func_AAD

    case{'LagProd'}
        % envelope of z_t:
        % |z_t| = |a(t)|^2 |R_{x}^{alpha0}(tau)|
        absRxa = sum(abs(z_t))/N;
        % absRxa is an estimate of |R_{x}^{alpha0}(tau)| only if a(t)=1
        % assumption: a(t)>0
        % [Napolitano 2019, Eq. (14.56)-(14.57)]
        a_t = sqrt(abs(z_t)/absRxa);
        
    otherwise
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Estimation of epsilon(t)

% unwrapped phase of z_t
argz_t = unwrap(angle(z_t));

% identifiability condition: |arg(z(t))| < pi (NO if arg() is the unwrapped phase)
maxargz = max(abs(argz_t));


argRxa = sum(argz_t)/T;

if (knownAlphaFlag==0)
   % Unknown (conjugate) cycle frequency: alpha0til is an estimate of alpha0
   % Estimation of the linear term (whose slope is proportional to the cycle
   % frequency error) present in the unwrapped angle of z_t

   if (lineEstimationMethod==1)
      LinePar = polyfit(tt,argz_t,1);
      m = LinePar(1); % slope
      q = LinePar(2); % intercept
   elseif (lineEstimationMethod==2)       
      m = sum(argz_t(2:N)-argz_t(1:N-1))/N;      
      q = argRxa;
   end

elseif (knownAlphaFlag==1)
   % known (conjugate) cycle frequency: alpha0til = alpha0    
   m = 0;      % no cycle frequency error <=> slope = 0
   q = argRxa; % if argRxa is not removed from argz_t
   % q = 0;   % if argz_t = argz_t-argRxa;
end

epsilon_t = (argz_t-(m*tt+q))/(2*pi*alpha0til);

alpha0est = alpha0til+m/(2*pi);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OUTPUT.func_AAD = func_AAD;
OUTPUT.sumModHarm_t = sumModHarm_t;
% OUTPUT.epsilon1_t = epsilon1_t;
% OUTPUT.epsilon2_t = epsilon2_t;
OUTPUT.maxargz = maxargz;
OUTPUT.argRxa = argRxa;
OUTPUT.m = m;
OUTPUT.q = q;
OUTPUT.alpha0est = alpha0est;
OUTPUT.alpha0til = alpha0til;

OUTPUT.functionInfo = functionInfo;
OUTPUT.InputParameters = INPUT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

return

