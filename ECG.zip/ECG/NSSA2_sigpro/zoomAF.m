% File: zoomAF.m
% Date: 21-APR-2022--22-APR-2022; 26-APR-2022--27-APR-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [Zzoom,OUTPUT] = zoomAF(Z,INPUT)

% spectra:
% zoom in [alpha1,alpha2) X [f1,f2)
% correlations:
% zoom in [alpha1,alpha2) X whole tau axis
% cycle frequency axis:
% zoom in [alpha1,alpha2)
% spectral frequency axis:
% zoom in [f1,f2)

functionInfo = 'zoomAF 27-APR-2022';

Ztype = INPUT.Ztype;

switch Ztype
    case{'spectrum','correlation'}
        % Z(alpha,f) or Z(alpha,tau)
        [Na,Nf] = size(Z);
    case{'alphaAxis'}
        Na = length(Z);
        Nf = Na; % dummy value
    case{'fAxis'}
        Nf = length(Z);
        Na = Nf; % dummy value
end

alphaInterval = defaultFieldValue('INPUT','alphaInterval',[-1/2,1/2]);
fInterval = defaultFieldValue('INPUT','fInterval',[-1/2,1/2]);
alphaStep = defaultFieldValue('INPUT','alphaStep',1/Na);
fStep = defaultFieldValue('INPUT','fStep',1/Nf);

Ztype = INPUT.Ztype;

% alpha axis: 
% if Na is even, alpha in [alpha1,alpha2) 
% if Na is odd, alpha in (alpha1,alpha2)
if (rem(Na,2)==0)
   ind_alphaZoom = indexFFT((alphaInterval(1):alphaStep:alphaInterval(2)-alphaStep),Na);
elseif (rem(Na,2)==1)
   ind_alphaZoom = indexFFT((alphaInterval(1)+alphaStep/2:alphaStep:alphaInterval(2)-alphaStep/2),Na);
end

% f axis: 
% if Nf is even, f in [f1,f2) 
% if Nf is odd, f in (f1,f2)
if (rem(Nf,2)==0)
   ind_fZoom = indexFFT((fInterval(1):fStep:fInterval(2)-fStep),Nf);
elseif (rem(Nf,2)==1)
   ind_fZoom = indexFFT((fInterval(1)+fStep/2:fStep:fInterval(2)-fStep/2),Nf);
end

switch Ztype
    case{'spectrum'}
        Z = ifftshift(Z);  % ifftshift along both dimensions (alpha,f)
        Zzoom = Z(ind_alphaZoom,ind_fZoom);

    case{'correlation'}
        Z = ifftshift(Z,1); % ifftshift along the 1st dimension (alpha)
        Zzoom = Z(ind_alphaZoom,:);

    case{'alphaAxis'}
        Z = ifftshift(Z);
        Zzoom = Z(ind_alphaZoom);

    case{'fAxis'}
        Z = ifftshift(Z);
        Zzoom = Z(ind_fZoom);

    otherwise

end

if (nargout==2)
    OUTPUT.functionInfo = functionInfo;
    OUTPUT.InputParameters = INPUT;
end

return