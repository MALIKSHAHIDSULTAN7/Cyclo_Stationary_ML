% File: AMTWACS_Estimation_debug_0.m
% date: 20-APR-2022--22-APR-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%
% Extracted from:
% File: AMTWACS_Estimation_debug.m
% Date: 06-SEP-2020--07-SEP-2020; 23-SEP-2020; 13-NOV-2020; 02-MAR-2021;
%       21-APR-2021; 14-NOV-2021--15-NOV-2021; 27-NOV-2021; 20-APR-2022;

function OUTPUT = AMTWACS_Estimation_debug_0(INPUT)

% parameters for the debug of AMTWACS_Estimation.m

epsilon_est_t = INPUT.epsilon_est_t;
% epsilon_proj_t = INPUT.epsilon_proj_t;
% epsilon_grad_t = INPUT.epsilon_grad_t;


N = length(epsilon_est_t);

OUTPUT.func_AAD = INPUT.func_AAD;

OUTPUT.N = N;
OUTPUT.da_string = 'da = 1/N';
OUTPUT.da = 1/N;

OUTPUT.maxargz = INPUT.OUTPUT_AMTWACS_AmplAngDemodZ.maxargz;
OUTPUT.twoSteps_flag = INPUT.twoSteps_flag;

OUTPUT.STEP1_m = INPUT.STEP1.m;
OUTPUT.STEP1_q = INPUT.STEP1.q;
OUTPUT.STEP1_alpha0til = INPUT.STEP1.alpha0til;
OUTPUT.STEP1_alpha0est = INPUT.STEP1.alpha0est;
OUTPUT.STEP1_mT = N*INPUT.STEP1.m;
alpha0est = INPUT.STEP1.alpha0est;

if (INPUT.twoSteps_flag == 1)
    OUTPUT.STEP2_m = INPUT.STEP2.m;
    OUTPUT.STEP2_q = INPUT.STEP2.q;
    OUTPUT.STEP2_alpha0til = INPUT.STEP2.alpha0til;
    OUTPUT.STEP2_alpha0est = INPUT.STEP2.alpha0est;
    OUTPUT.STEP2_mT = N*INPUT.STEP2.m;
    alpha0est = INPUT.STEP2.alpha0est;
else
    OUTPUT.STEP2 = struct([]);
end
    
% output that is displayed during run
OUTPUT.display = OUTPUT;

% Condition to approximate exp(j*2*pi*alpha0*epsilon(t)) = constant complex number:
% [Napolitano 2019, Eq. (14.49)]
% sup_t |epsilon(t)-<epsilon(t)>| << 1/(2*pi*|alpha0|) 
OUTPUT.maxepsilon0mean_est = max(abs(epsilon_est_t - sum(epsilon_est_t)/N));
% OUTPUT.maxepsilon0mean_proj = max(abs(epsilon_proj_t - sum(epsilon_proj_t)/N));
% OUTPUT.maxepsilon0mean_grad = max(abs(epsilon_grad_t - sum(epsilon_grad_t)/N));
OUTPUT.cond_e0mean = 'max |epsilon(t)-<epsilon(t)>| << 1/|2*pi*alpha0est|';
OUTPUT.one_over_2pialpha0 = 1/abs(2*pi*alpha0est);

% Condition for using method = 13 in warping.m 
% max |epsilon_est(t)|
OUTPUT.maxepsilon_est = max(abs(epsilon_est_t));
% OUTPUT.maxepsilon_proj = max(abs(epsilon_proj_t));
% OUTPUT.maxepsilon_grad = max(abs(epsilon_grad_t));
OUTPUT.cond_e = 'max |epsilon(t)/Ts| < D (number of sinc functions for dewarping)';

% Condition for the validity of the approximate expression [Napolitano 2017, Eq. (3.15)]
% for the TW-ACS signal y(t) = x(t+epsilon(t)), x(t) ACS:
% [Napolitano 2017, Eq. (3.14)], [Napolitano 2019, Eq. (14.40)]
% sup_t |d epsilon(t)/d t| << 1 

% dt = 1

% max |d epsilon_est(t)/d t|
OUTPUT.maxDepsilon_est = max(abs(epsilon_est_t(2:end)-epsilon_est_t(1:end-1)));

% % max |d epsilon_proj(t)/d t|
% OUTPUT.maxDepsilon_proj = max(abs(epsilon_proj_t(2:end)-epsilon_proj_t(1:end-1)));
% 
% % max |d epsilon_proj(t)/d t|
% OUTPUT.maxDepsilon_grad = max(abs(epsilon_grad_t(2:end)-epsilon_grad_t(1:end-1)));

OUTPUT.cond_de = 'max |d epsilon(t)/d t| << 1';

% (1/T) Integral [d epsilon_est(t)/d t] dt
OUTPUT.IntegralDepsilon_est = sum(epsilon_est_t(2:end)-epsilon_est_t(1:end-1))/N;

% % (1/T) Integral [d epsilon_proj(t)/d t] dt
% OUTPUT.IntegralDepsilon_proj = sum(epsilon_proj_t(2:end)-epsilon_proj_t(1:end-1))/N;
% 
% % (1/T) Integral [d epsilon_grad(t)/d t] dt
% OUTPUT.IntegralDepsilon_grad = sum(epsilon_grad_t(2:end)-epsilon_grad_t(1:end-1))/N;
 
OUTPUT.cond_Int_de = '(1/T) Integral [d epsilon(t)/d t] dt << |alpha0 - alpha0til|';

% OUTPUT.error = INPUT.OUTPUT_AMTWACS_maxObjectiveFunction.error;
% OUTPUT.nit = INPUT.OUTPUT_AMTWACS_maxObjectiveFunction.nit;

return