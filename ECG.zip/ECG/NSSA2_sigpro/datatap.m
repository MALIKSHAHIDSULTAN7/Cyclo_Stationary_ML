% File: datatap.m
% Date: 26-MAY-2004; 10-JUN-2019; 14-OCT-2020--15-OCT-2020; 05-MAY-2021;
%       21-APR-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function Z = datatap(N,dtwindow)
% data tapering window

Ts = 1;
t = 0:Ts:(N-1)*Ts;
if strcmp(dtwindow,'Blackman')
   Z = (.42 - .5*cos(2*pi*t/(N-1)) + .08*cos(4*pi*t/(N-1)));
elseif strcmp(dtwindow,'Hanning')
   Z = .5*(1 - cos(2*pi*(t+Ts)/(N+1)));
elseif strcmp(dtwindow,'Hamming')
   Z = .54 - .46*cos(2*pi*t/(N-1));
elseif strcmp(dtwindow,'Sinc')||strcmp(dtwindow,'sinc')
   Z = sinc((t-N*Ts/2)/(N*Ts/2));       
elseif strcmp(dtwindow,'Sinc2')||strcmp(dtwindow,'sinc2')
   Z = (sinc((t-N*Ts/2)/(N*Ts/2))).^2;       
elseif strcmp(dtwindow,'Rect')||strcmp(dtwindow,'rect')||...
       strcmp(dtwindow,'None')||strcmp(dtwindow,'none') 
   Z = ones(1,N);       
elseif strcmp(dtwindow,'Triangular')|| ...
       strcmp(dtwindow,'Triangle')||strcmp(dtwindow,'triangle')
   Z = 1-abs(t-N*Ts/2)/(N*Ts/2); 
else
   Z = ones(1,N); 
end
% BLACKMAN BLACKMAN(N) returns the N-point Blackman window.
% w = (.42 - .5*cos(2*pi*(0:n-1)/(n-1)) + .08*cos(4*pi*(0:n-1)/(n-1)))';
% HANNING HANNING(N) returns the N-point Hanning window in a column vector.
% w = .5*(1 - cos(2*pi*(1:n)'/(n+1)));
% HAMMING HAMMING(N) returns the N-point Hamming window.
% w = .54 - .46*cos(2*pi*(0:n-1)'/(n-1));
return
