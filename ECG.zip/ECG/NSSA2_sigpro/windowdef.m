% File: windowdef.m
% Date: 16-AUG-2017; 12-NOV-2018; 16-NOV-2018; 09-SEP-2021;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%
% Usage:
% w=windowdef('sinc');
% tt=(-N:N);
% x=w((tt-t0)/M);

function w=windowdef(name)

switch name

    case{'rect','Rect'}
       w = @(t) double(abs(t)<=1/2); 
    case{'sinc','Sinc'} 
       w = @(t) sinc(t); 
    case{'sinc2','Sinc2'} 
       w = @(t) (sinc(t)).^2; 
    case{'triangle','Triangle'}
       w = @(t) (1-abs(t)).*(abs(t)<=1);
    case{'none','None'}
       w = @(t) 1.0; 
    otherwise
       w = @(t) 1.0; 
        
end

return