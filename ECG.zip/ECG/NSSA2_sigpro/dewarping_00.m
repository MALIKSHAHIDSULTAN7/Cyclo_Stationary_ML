% File: dewarping_0.m
% Date: 21-APR-2022;
%
% Shared version of:
% dewarping_0.m 21-APR-2022;
% Extracted from:
% dewarping.m 28-MAR-2021;
%
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%

function [x_t] = dewarping_00(y_t,INPUT)

% time-warping function:
% psi(t) = t+epsilon(t)
%
% time-warped signal:
% y(t) = x(psi(t)) = x(t+epsilon(t))
%
% estimated time-warping function:
% psi_est(t) = t+epsilon_est(t)
  
a_est_t = INPUT.a_est_t;
epsilon_est_t = INPUT.epsilon_est_t;

% row vectors
y_t = y_t(:).';
a_est_t = a_est_t(:).';
epsilon_est_t = epsilon_est_t(:).';

y_t = y_t./a_est_t;

Ts = 1;
N = length(y_t);
tt = (0:1:N-1)*Ts;

psi_t = tt - epsilon_est_t;

INPUT.warping.warpingType = 'time'; 
INPUT.warping.psi = psi_t;       % time- or frequency-warping function or vector
INPUT.warping.method = INPUT.method; 
INPUT.warping.sym = 0;
INPUT.warping.clipType = 0;
INPUT.warping.D = INPUT.D;

% [x_t,~] = warping(y_t,INPUT.warping);
[x_t,~] = warping_00(y_t,INPUT.warping);

return