% File: printFile.m
% Date: 26-JUN-2019; 10-JAN-2020; 27-JAN-2021; 13-APR-2021; 12-JUL-2021;
%       19-JUL-2021; 23-SEP-2021; 25-JAN-2022; 21-APR-2022;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%
% HISTORY:
% PrintPostScript.m
% 20-MAR-2009; 23-MAR-2010; 02-APR-2013; 02-JAN-2014; 07-JUL-2014; 
% 28-JUL-2014; 01-APR-2016;

function Z = printFile(fileName,fileType)

% for the current figure, printFile.m creates a file of the specified format 

% default values
if     (nargin==1); fileType = 'ps';
elseif (nargin==0); fileType = 'ps'; fileName = 'PostScriptFile';
end

Z = 1; % generated figure file

MatlabVersion = version;

switch fileType
    
    case{'Jpeg','jpeg','jpg'}
        fprintf(1,'Print Jpeg: %s \n',fileName);
        % saveas([FileName,'.jpg'],'jpeg');  % low resolution
        print('-djpeg100',[fileName,'.jpg']);   % medium resolution
        
        % alternative command with saveas
        % saveas(gcf,[fileName,'.jpg']);

    case{'JpegHighResolution'}
        fprintf(1,'Print Jpeg High Resolution: %s \n',fileName);
        % print('-r400','-djpeg100','-painters',[fileName,'.jpg']);   % high resolution
        print('-r400','-djpeg100','-vector',[fileName,'.jpg']);   % high resolution

    case{'ps'}             
        % high-quality and small-size 3D plots   
        fprintf(1,'Print PostScript: %s \n',fileName);
        if (MatlabVersion(1)>=9)   
           % zbuffer is deprecated in new versions of Matlab
           % print -djpeg100 fig.jpg
           % print('-r400','-djpeg100','-painters','fig.jpg');   % high resolution
           print('-r400','-djpeg100','-vector','fig.jpg');   % high resolution
        else
           % zbuffer is needed in old versions of Matlab
           print -zbuffer -djpeg100 fig.jpg
        end
        % ! jpeg2ps fig.jpg > figure1.ps
        % ! del fig.jpg

        %%%% The following path names work also if filename is not within " " 
        %%% PathJ='C:\Progra~1\GnuWin32\bin\'; % Path for jpeg2ps (WIN 32)
        %%% PathJ='C:\Progra~2\GnuWin32\bin\'; % Path for jpeg2ps (WIN 64)
        %%% DosCommand=strcat(PathJ,'jpeg2ps fig.jpg > ',FigFileName,'.ps');
   
        %%% The following path names work only if filename is within " " 
        %PathJ='C:\Program Files\GnuWin32\bin\'; % Path for jpeg2ps (WIN 32)
        PathJ = 'C:\Program Files (x86)\GnuWin32\bin\'; % Path for jpeg2ps (WIN 64)
        DosCommand = strcat('"',PathJ,'jpeg2ps" fig.jpg > ',fileName,'.ps');
   
        system(DosCommand);
        system('del fig.jpg');
    
    case{'PostScript','ps2'}    
        % high-quality and small-size 2D and 3D plots
        fprintf(1,'Print PostScript: %s \n',fileName);
        print('-deps',[fileName,'.ps']); 
        
    case{'PostScriptColor','ps3'}    
        % PostScript Color
        fprintf(1,'Print PostScript Color: %s \n',fileName);
        print('-depsc',[fileName,'.ps']); 

    case{'pdf_large','PDF_large'}    
        % Portable Document Format (PDF)
        fprintf(1,'Print PDF: %s \n',fileName);
        fprintf(1,'WARNING: VERY LARGE FILE \n');
        print('-dpdf',[fileName,'.pdf']);
        
    case{'pdf','PDF'} 
        % Portable Document Format (PDF)
        PathE = 'C:\Program Files\MiKTeX\miktex\bin\x64\';
        fprintf(1,'Print PDF: %s \n',fileName);
        print('-depsc','fig.ps');      % high-quality PostScrip file
        
        % convert PostScrit into PDF file
        % use epstopdf, do not use ps2pdf
        DosCommand = ['"',PathE,'epstopdf" fig.ps --outfile ',fileName,'.pdf'];
   
        system(DosCommand);
        system('del fig.ps');
        
    case{'png'}
        % PNG 24-bit
        fprintf(1,'Print PNG: %s \n',fileName);
        print('-dpng',[fileName,'.png']);
        
    case{'tiffn'}
        % TIFF 24-bit (not compressed)
        fprintf(1,'Print TIFF (not compressed): %s \n',fileName);
        print('-dtiffn',[fileName,'.tif']);

    case{'tiff'}
        % TIFF 24-bit (compressed)
        fprintf(1,'Print TIFF (compressed): %s \n',fileName);
        print('-dtiff',[fileName,'.tif']);

    case{'MatlabFig'}
        % save Matlab Fig File
        % The FIG-file stores the information required to recreate the figure
        % using Matlab later
        savefig([fileName,'.fig']);
        
        % alternative 
        % saveas(gcf,[fileName,'.fig']);
        
        % to open this fig file:
        % openfig([fileName,'.fig']);
               
    case{'MatlabCode'}
        % Matlab Code
        % saveas(gcf,[fileName,'.m']); % NO
        fprintf(1,'File > Generate Code \n')
        fprintf(1,'generate Matlab function: createfigure.m \n');

    case{'none','NONE','None'}
        % do nothing
        Z = 0;
    
    otherwise       
        fprintf(1,'ERROR: no valid fileType');
        Z = 0; % no figure file
        
end

return