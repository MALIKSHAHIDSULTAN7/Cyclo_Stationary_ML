% File: globaltitle.m
% Date: 18-JUL-2020--19-JUL-2020; 31-JUL-2020; 16-AUG-2020;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function globaltitle(titlestring,iLabelFontSize)
% puts a global title in a figure with subplot()
a = axes;
t1 = title(titlestring);
% Compatible with Matlab but not Octave
% a.Visible = 'off'; % set(a,'Visible','off');
% t1.Visible = 'on'; % set(t1,'Visible','on');
% t1.FontSize = iLabelFontSize; %set(t1,'FontSize',iLabelFontSize);
% Compatible with Matlab and Octave
set(a,'Visible','off');
set(t1,'Visible','on');
set(t1,'FontSize',iLabelFontSize);
return