% File: myaxis.m
% Date: 11-MAR-2015;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [x1,x2,y1,y2]=myaxis(x,y)
%
% Usage:
% [x1,x2,y1,y2]=myaxis(x,y);
% axis([x1,x2,y1,y2]);

x1=x(1);
x2=x(end);

ymax=max(max(real(y)),max(imag(y)));
ymin=min(min(real(y)),min(imag(y)));
y1=ymin-0.1*(ymax-ymin);
y2=ymax+0.1*(ymax-ymin);

return
