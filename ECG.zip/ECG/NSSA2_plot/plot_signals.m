% plot signals

% load workspace
% workspaceFile = 'wksp_ECGanalysis.mat';
% load(workspaceFile);

% Np = 2000;
Np = 4000;

Np = min(Np,length(OUT.y.y_t));

fh = figure(NumFig); clf;
set(fh,'Name','y(t), x(t), xp(t), xr(t)');
subplot(2,1,1)
fig_h = plot((1:Np),OUT.y.y_t(1:Np));
set(fig_h,'LineWidth',1,'LineStyle','-','Color','black');
hold on
fig_h = plot((1:Np),OUT.x.x_t(1:Np));
set(fig_h,'LineWidth',1,'LineStyle','-','Color','blue');
xlabel('t/T_s');
legend('ECG signal y(t)','underlying CS signal x(t)');
hold off

subplot(2,1,2)
fig_h = plot((1:Np),OUT.x.xp_t(1:Np));
set(fig_h,'LineWidth',1,'LineStyle','-','Color','green');
hold on
fig_h = plot((1:Np),OUT.x.xr_t(1:Np));
set(fig_h,'LineWidth',1,'LineStyle','-','Color','red');
xlabel('t/T_s');
legend('periodic signal x_p(t)','zero-mean CS signal x_r(t)');
hold off

NumFig = NumFig+1;
