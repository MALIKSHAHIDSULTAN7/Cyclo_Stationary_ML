% File: plotCmplxVectors.m
% Date: 06-OCT-2021; 29-JAN-2022; 04-JUL-2022; 08-APR-2023; 05-JUL-2023;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%
% HISTORY:
% plotAbsArgReIm4.m
% 27-JUL-2020--31-JUL-2020; 26-AUG-2020; 02-SEP-2020; 04-APRIL-2021;
% 11-APR-2021--13-APR-2021; 27-JUL-2021; 11-SEP-2021;
% plotAbsArgReIm3.m
% 19-OCT-2012; 21-MAR-2013; 08-JAN-2014; 03-APR-2014; 28-MAY-2014;
% 26-AUG-2014; 09-SEP-2014; 05-APR-2016; 05-MAY-2016;
% plotAbsArgReIm2.m 
% 04-AUG-2009; 07-AUG-2009; 10-AUG-2009;
%
% Plot of |Z(t)|, arg[Z(t)], Re[Z(t)], Im[Z(t)] 
% of the complex-valued functions Z1(xx1), Z2(xx2), and Z3(xx3) as function of
% the real-valued vectors xx1, xx2, and xx3.

function plotCmplxVectors(INPUT,FigLabels,FigParameters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = length(INPUT.Z1);

% if ~isfield(INPUT,'Z1'); INPUT.Z1 = (1+1j)*NaN*ones(1,N); end
if ~isfield(INPUT,'xx1')||isempty(INPUT.xx1); INPUT.xx1 = (1:N); end
Z1 = INPUT.Z1;
xx1 = INPUT.xx1;

if ~isfield(INPUT,'Z2')||isempty(INPUT.Z2); INPUT.Z2 = (1+1j)*NaN*ones(1,N); end
if ~isfield(INPUT,'xx2')||isempty(INPUT.xx2); INPUT.xx2 = xx1; end
Z2 = INPUT.Z2;
xx2 = INPUT.xx2;

if ~isfield(INPUT,'Z3')||isempty(INPUT.Z3); INPUT.Z3 = (1+1j)*NaN*ones(1,N); end
if ~isfield(INPUT,'xx3')||isempty(INPUT.xx3); INPUT.xx3 = xx1; end
Z3 = INPUT.Z3;
xx3 = INPUT.xx3;

% default values for missed input parameters
if ~isfield(FigLabels,'x')||isempty(FigLabels.x); FigLabels.x = ''; end
if ~isfield(FigLabels,'title')||isempty(FigLabels.title); FigLabels.title = ''; end
if ~isfield(FigLabels,'comment')||isempty(FigLabels.comment); FigLabels.comment = ''; end
if ~isfield(FigParameters,'labelType')||isempty(FigParameters.labelType); FigParameters.labelType = 2; end
if ~isfield(FigParameters,'LogFlag')||isempty(FigParameters.LogFlag); FigParameters.LogFlag = 0; end
if ~isfield(FigParameters,'NumFig')||isempty(FigParameters.NumFig); FigParameters.NumFig = 1; end
if ~isfield(FigParameters,'FigName')||isempty(FigParameters.FigName); FigParameters.FigName = ''; end
if ~isfield(FigParameters,'FigID')||isempty(FigParameters.FigID); FigParameters.FigID = ''; end
if ~isfield(FigParameters,'iLabelFontSize')||isempty(FigParameters.iLabelFontSize); FigParameters.iLabelFontSize = 12; end
if ~isfield(FigParameters,'iAxisFontSize')||isempty(FigParameters.iAxisFontSize); FigParameters.iAxisFontSize = 12; end
if ~isfield(FigParameters,'FigMode')||isempty(FigParameters.FigMode); FigParameters.FigMode = 'subplot'; end
if ~isfield(FigParameters,'printFileType')||isempty(FigParameters.printFileType); FigParameters.printFileType = 'none'; end
if ~isfield(FigParameters,'printFileFlag')||isempty(FigParameters.printFileFlag); FigParameters.printFileFlag = 0; end
if ~isfield(FigParameters,'zoomXAxisFlag')||isempty(FigParameters.zoomXAxisFlag); FigParameters.zoomXAxisFlag = 0; end
if ~isfield(FigParameters,'xlimits')||isempty(FigParameters.xlimits); FigParameters.xlimits = [xx1(1),xx1(end)]; end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x_label = FigLabels.x;
title_label = FigLabels.title;
comment = FigLabels.comment;
labelType = FigParameters.labelType;
LogFlag = FigParameters.LogFlag;
NumFig = FigParameters.NumFig;         
FigName = FigParameters.FigName;         
FigID = FigParameters.FigID;
iLabelFontSize = FigParameters.iLabelFontSize;
iAxisFontSize = FigParameters.iAxisFontSize;
FigMode = FigParameters.FigMode;   % 'normal' 'subplot'
printFileType = FigParameters.printFileType; % 'PostScript' 'Jpeg'
printFileFlag = FigParameters.printFileFlag;
zoomXAxisFlag = FigParameters.zoomXAxisFlag;
xlimits = FigParameters.xlimits;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Colors1 = char('black','blue','green');
LineStyles1 = char('-','-','-');
%LineStyles1 = char('-',':','-.','--');
% LineWidths1 = [2,1,1];
LineWidths1 = [1.5,1,1];

iFontSize = iAxisFontSize;
strFontUnit = 'points';
strFontName = 'Times';
strFontWeight = 'normal';
% strInterpreter='latex';

if strcmp(FigMode,'normal')
   fh = figure(NumFig); clf;
   set(fh,'Name',[FigName,' (magnitude)']);
elseif strcmp(FigMode,'subplot')
   fh = figure(NumFig); clf;
   set(fh,'Name',FigName);
   subplot(2,2,1),
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (LogFlag==0)
   hold on;
   fig_1 = plot(xx1,abs(Z1));
   set(fig_1,'Linewidth',LineWidths1(1),'Color',deblank(Colors1(1,:)),'LineStyle',LineStyles1(1));
   fig_2 = plot(xx2,abs(Z2));
   set(fig_2,'Linewidth',LineWidths1(2),'Color',deblank(Colors1(2,:)),'LineStyle',LineStyles1(2));
   fig_3 = plot(xx3,abs(Z3));
   set(fig_3,'Linewidth',LineWidths1(3),'Color',deblank(Colors1(3,:)),'LineStyle',LineStyles1(3));
elseif (LogFlag==1)
   hold on;
   fig_1 = plot(xx1,10*log10(abs(Z1)));
   set(fig_1,'Linewidth',LineWidths1(1),'Color',deblank(Colors1(1,:)),'LineStyle',LineStyles1(1));
   fig_2 = plot(xx2,10*log10(abs(Z2)));
   set(fig_2,'Linewidth',LineWidths1(2),'Color',deblank(Colors1(2,:)),'LineStyle',LineStyles1(2));
   fig_3 = plot(xx3,10*log10(abs(Z3)));
   set(fig_3,'Linewidth',LineWidths1(3),'Color',deblank(Colors1(3,:)),'LineStyle',LineStyles1(3));
end
if (zoomXAxisFlag==1)
    xlim(xlimits)
end
hold off;
grid;    

set(gca,'FontName',strFontName,'FontSize',iFontSize, ...
        'FontUnits',strFontUnit,'FontWeight',strFontWeight);

if (labelType==1)
   if (LogFlag==0)
      title_string = ['|',title_label,'| ',comment];
   elseif (LogFlag==1)
      title_string = ['|',title_label,'|  (dB) ',comment];
   end
   h = title(title_string);
   set(h,'FontSize',iLabelFontSize);
elseif (labelType==2)
   if (LogFlag==0)
      y_label = 'magnitude';
   elseif (LogFlag==1)
      y_label = 'magnitude (dB)';
   end
   h = ylabel(y_label);
   set(h,'FontSize',iLabelFontSize);   
   if strcmp(FigMode,'normal')
      title_string = [title_label,' ',comment];
      h = title(title_string);
      set(h,'FontSize',iLabelFontSize);
   end
end

if strcmp(FigMode,'normal') 
   h = xlabel(x_label);
   set(h,'FontSize',iLabelFontSize); 
end

% print file
if (printFileFlag==1)&&(strcmp(FigMode,'normal'))
   FigFileName = strcat('Fig_',FigID,'_Abs');
   printFile(FigFileName,printFileType);
end   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if strcmp(FigMode,'normal')
   fh = figure(NumFig+1); clf;    
   set(fh,'Name',[FigName,' (phase)']);
elseif strcmp(FigMode,'subplot')
   fh = figure(NumFig);
   set(fh,'Name',FigName);
   subplot(2,2,3),
end

hold on;
fig_1 = plot(xx1,angle(Z1));
set(fig_1,'Linewidth',LineWidths1(1),'Color',deblank(Colors1(1,:)),'LineStyle',LineStyles1(1));
fig_2 = plot(xx2,angle(Z2));
set(fig_2,'Linewidth',LineWidths1(2),'Color',deblank(Colors1(2,:)),'LineStyle',LineStyles1(2));
fig_3 = plot(xx3,angle(Z3));
set(fig_3,'Linewidth',LineWidths1(3),'Color',deblank(Colors1(3,:)),'LineStyle',LineStyles1(3));
if (zoomXAxisFlag==1)
    xlim(xlimits)
end
hold off;
grid;    
   
set(gca,'FontName',strFontName,'FontSize',iFontSize, ...
        'FontUnits',strFontUnit,'FontWeight',strFontWeight);

if (labelType==1)
   title_string = ['arg[',title_label,'] ',comment];
   h = title(title_string);
   set(h,'FontSize',iLabelFontSize);
elseif (labelType==2)
   y_label = 'phase';
   h = ylabel(y_label);
   set(h,'FontSize',iLabelFontSize);
   if strcmp(FigMode,'normal')
      title_string = [title_label,' ',comment];
      h = title(title_string);
      set(h,'FontSize',iLabelFontSize);
   end
end

h = xlabel(x_label);
set(h,'FontSize',iLabelFontSize); 

% print file
if (printFileFlag==1)&&(strcmp(FigMode,'normal'))
   FigFileName = strcat('Fig_',FigID,'_Arg');
   printFile(FigFileName,printFileType);
end   


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if strcmp(FigMode,'normal')
   fh = figure(NumFig+2); clf;
   set(fh,'Name',[FigName,' (real part)']);
elseif strcmp(FigMode,'subplot')
   fh = figure(NumFig);
   set(fh,'Name',FigName);
   subplot(2,2,2),
end

hold on;
fig_1 = plot(xx1,real(Z1));
set(fig_1,'Linewidth',LineWidths1(1),'Color',deblank(Colors1(1,:)),'LineStyle',LineStyles1(1));
fig_2 = plot(xx2,real(Z2));
set(fig_2,'Linewidth',LineWidths1(2),'Color',deblank(Colors1(2,:)),'LineStyle',LineStyles1(2));
fig_3 = plot(xx3,real(Z3));
set(fig_3,'Linewidth',LineWidths1(3),'Color',deblank(Colors1(3,:)),'LineStyle',LineStyles1(3));
if (zoomXAxisFlag==1)
    xlim(xlimits)
end
hold off;
grid;    

set(gca,'FontName',strFontName,'FontSize',iFontSize, ...
        'FontUnits',strFontUnit,'FontWeight',strFontWeight);

if (labelType==1)
   title_string = ['real[',title_label,'] ',comment];
   h = title(title_string);
   set(h,'FontSize',iLabelFontSize);
elseif (labelType==2)
   y_label = 'real part';
   h = ylabel(y_label);
   set(h,'FontSize',iLabelFontSize);
   if strcmp(FigMode,'normal')
      title_string = [title_label,' ',comment];
      h = title(title_string);
      set(h,'FontSize',iLabelFontSize);
   end
end

if strcmp(FigMode,'normal') 
   h = xlabel(x_label);
   set(h,'FontSize',iLabelFontSize); 
end

% print file
if (printFileFlag==1)&&(strcmp(FigMode,'normal'))
   FigFileName = strcat('Fig_',FigID,'_Re');
   printFile(FigFileName,printFileType);
end   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if strcmp(FigMode,'normal')
   fh = figure(NumFig+3); clf;  
   set(fh,'Name',[FigName,' (imaginary part)']);
elseif strcmp(FigMode,'subplot')
   fh = figure(NumFig);
   set(fh,'Name',FigName);
   subplot(2,2,4),
end

hold on;
fig_1 = plot(xx1,imag(Z1));
set(fig_1,'Linewidth',LineWidths1(1),'Color',deblank(Colors1(1,:)),'LineStyle',LineStyles1(1));
fig_2 = plot(xx2,imag(Z2));
set(fig_2,'Linewidth',LineWidths1(2),'Color',deblank(Colors1(2,:)),'LineStyle',LineStyles1(2));
fig_3 = plot(xx3,imag(Z3));
set(fig_3,'Linewidth',LineWidths1(3),'Color',deblank(Colors1(3,:)),'LineStyle',LineStyles1(3));
if (zoomXAxisFlag==1)
    xlim(xlimits)
end
hold off;
grid;    

set(gca,'FontName',strFontName,'FontSize',iFontSize, ...
        'FontUnits',strFontUnit,'FontWeight',strFontWeight);

if (labelType==1)
   title_string = ['imag[',title_label,'] ',comment];
   h = title(title_string);
   set(h,'FontSize',iLabelFontSize);
elseif (labelType==2)
   y_label = 'imaginary part';
   h = ylabel(y_label);
   set(h,'FontSize',iLabelFontSize);
   if strcmp(FigMode,'normal')
      title_string = [title_label,' ',comment];
      h = title(title_string);
      set(h,'FontSize',iLabelFontSize);
   end
end

h = xlabel(x_label);
set(h,'FontSize',iLabelFontSize); 

% print file
if (printFileFlag==1)&&(strcmp(FigMode,'normal'))
   FigFileName = strcat('Fig_',FigID,'_Im');
   printFile(FigFileName,printFileType);
end   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (strcmp(FigMode,'subplot'))&&(labelType==2)
   
   title_string = [title_label,comment];
   globaltitle(title_string,iLabelFontSize);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % figure('Name',figureName) DOES NOT WORK WITH SUBPLOT

% if strcmp(FigMode,'normal')
%    % figure('Name',figureName);
% elseif strcmp(FigMode,'subplot')
%    figure(NumFig); 
%    figure('Name',figureName);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% print file
if (printFileFlag==1)&&(strcmp(FigMode,'subplot'))
   FigFileName = strcat('Fig_',FigID);
   printFile(FigFileName,printFileType);
end   

return
