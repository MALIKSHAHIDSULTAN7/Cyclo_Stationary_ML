% File: myFigStyle.m
% Date: 20-JUN-2016;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function myFigStyle(iAxisFontSize)

iFontSize=iAxisFontSize;
strFontUnit='points';
% strFontName='Times';
strFontName='Helevetica';
strFontWeight='normal';
% strInterpreter='latex';
set(gca,'FontName',strFontName,'FontSize',iFontSize, ...
        'FontUnits',strFontUnit,'FontWeight',strFontWeight);

return