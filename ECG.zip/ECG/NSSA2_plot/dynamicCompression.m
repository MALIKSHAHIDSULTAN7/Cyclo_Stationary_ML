% File: dynamicCompression.m
% Date: 08-JAN-2014; 07-AUG-2016; 23-AUG-2020;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function Zc=dynamicCompression(Z,Dynamic_dB)
% Z  = vector of complex elements
% Zc = vector Z with dynamic compressed at Dynamic_dB decibels
Zc=Z;
[Zmax,~]=max(abs(Z));
Icomp=(10*log10(abs(Z)/Zmax)<=-Dynamic_dB);
Zc(Icomp)=Zmax*10^(-Dynamic_dB/10).*exp(1j*angle(Z(Icomp)));
return