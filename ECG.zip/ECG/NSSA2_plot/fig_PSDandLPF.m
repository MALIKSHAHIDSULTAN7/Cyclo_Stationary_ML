% File: fig_PSDandLPF.m
% Date: 14-NOV-2021--15-NOV-2021; 24-NOV-2021;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function fig_PSDandLPF(INPUT)

DynamicRange_dB = INPUT.DynamicRange_dB;
iAxisFontSize = INPUT.iAxisFontSize;
F1 = INPUT.F1;
Wlpf = INPUT.Wlpf;
PSD = INPUT.PSD;
title_string = INPUT.title_string;


N = length(PSD);

lpf = NaN*ones(1,N);
PSD = dynamicCompression(PSD,DynamicRange_dB);
% Ind = indexFFT((-Wlpf:1/N:Wlpf),N);       % NO
% Ind = round((-Wlpf:1/N:Wlpf)*N+(N/2+1));  % YES only for DFT, not for CZT
hz = (F1(end)-F1(1))/N;
Ind = round((-Wlpf:hz:Wlpf)*(1/hz)+(N/2+1));
lpf(Ind) = 1.1*max(abs(PSD))*ones(1,length(Ind));
lpf(Ind(1)-1) = min(abs(PSD)); 
lpf(Ind(end)+1) = min(abs(PSD));
% semilogy(F1,abs(PSD),'b',F1,lpf,'r');
% fig_1 = semilogy(F1,abs(PSD));
fig_1 = plot(F1,10*log10(abs(PSD)));
set(fig_1,'LineWidth',1,'LineStyle','-','Color','black');
hold on;
% fig_2=semilogy(F1,lpf);
fig_2 = plot(F1,10*log10(lpf));
% set(fig_2,'Linewidth',0.5,'Color','red');
set(fig_2,'LineWidth',1.5,'LineStyle',':','Color','black');
hold off;
xlabel('f/f_s');
ylabel('(dB)');
title(title_string);
myFigStyle(iAxisFontSize);

return

