function y=shiftlr(a,n,cs)

% SHIFTLR Shifts or Circularly Shifts Matrix Columns.
%
% SHIFTLR(A,N) with N>0 shifts the columns of A to the RIGHT N columns.
% The first N columns are replaced by zeros and the last N
% columns of A are deleted.
%
% SHIFTLR(A,N) with N<0 shifts the columns of A to the LEFT N columns.
% The last N columns are replaced by zeros and the first N
% columns of A are deleted.
%
% SHIFTLR(A,N,CS) where CS is nonzero performs a circular
% shift of N columns, where columns circle back to the other
% side of the matrix. No columns are replaced by zeros.

if nargin<3, cs=0; end
y=(shiftud(a.',n,cs)).';   % transposes the input, calls shiftud,
                           % and then transposes the result
return