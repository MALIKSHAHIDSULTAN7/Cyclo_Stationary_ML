% File: main_ECGanalysis_SH.m
% Date: 10-MAR-2025;
% 
% Shared version of:
% main_ECGanalysis.m 24-JUL-2023;
% Author: Antonio Napolitano
% (antnapol@gmail.com https://sites.google.com/site/antnapol)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INPUT PARAMETERS 

% dataFile = '.\files\mat\m001_1.mat';
dataFile = '.\files\mat\m003_1.mat';
Fs = 5000;  % sampling frequency before downsampling
signalNumber = 1; % lead I
% signalNumber = 2; % lead II
Mdec = 25;  % downsampling factor Fs/Mdec = 200 Hz       
LPFbandwidth                = 0.003; % low-pass filter bandwidth 
spectralFrequencyResolution = 1/256; % spectral frequency resolution
Nmax = 10^4;       % maximum number of samples

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


addpath(genpath('.\'));

load(dataFile,'signal');

y_t = signal(1:Mdec:end,signalNumber);
clear signal

INPUT.LPFbandwidth                = LPFbandwidth;
INPUT.spectralFrequencyResolution = spectralFrequencyResolution;
% INPUT.minPeakProminence = 0.7;
INPUT.minPeakProminence = [];
INPUT.samplingFrequency = Fs/Mdec;

INPUT.f_a = -1/2;
INPUT.f_b = 1/2;
% INPUT.alphaZoomOversamplingFactor = 1;
INPUT.alphaZoomOversamplingFactor = 2;

N = min([Nmax,length(y_t)]);
y_t = y_t(1:N);

fprintf(1,'dataFile = %s | %s \n',dataFile,datestr(now));

[OUTPUT.ECGanalysis] = ECGanalysis_SH(y_t,INPUT);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% save workspace
workspaceFile = 'wksp_ECGanalysis.mat';
save(workspaceFile);

