% File: defaultFieldValue.m
% Date: 21-APR-2022--22-APR-2022; 06-APR-2023; 27-APR-2023;

function Z = defaultFieldValue(structureName,fieldName,defaultValue)

% structureName = string containing the name of a structure
% fieldName = string containing the name of a field of structure

WkspVars = evalin('caller','who');

for k = 1:size(WkspVars,1)
    WStruct.(WkspVars{k}) = evalin('caller',WkspVars{k});
end

if ~isfield(WStruct,structureName)
   WStruct.(structureName) = [];
end

if ~isfield(WStruct.(structureName),fieldName)||isempty(WStruct.(structureName).(fieldName)) 
    WStruct.(structureName).(fieldName) = defaultValue;
    % update structure
    assignin('caller',structureName,WStruct.(structureName));
    if (nargout==1)
       Z = defaultValue;
    end
else
    if (nargout==1)
       Z = WStruct.(structureName).(fieldName);
    end    
end

return
