% File: ECGanalysis_SH.m
% Date: 10-MAR-2025; 12-MAR-2025;
%
% Shared version of: 
% ECGanalysis.m   24-JUL-2023;
% Author: Antonio Napolitano 
% (antnapol@gmail.com https://sites.google.com/site/antnapol)

function [OUTPUT] = ECGanalysis_SH(y_t,INPUT)

functionInfo = 'ECGanalysis.m 24-JUL-2023';

% addpath('.\matlab0');
% addpath('.\sigpro');
% addpath('.\utilities');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fse = INPUT.samplingFrequency;
Wlpf = INPUT.LPFbandwidth;
Deltaf = INPUT.spectralFrequencyResolution;
% alpha0til = INPUT.alpha0til;

% k_med = INPUT.k_medianFiltering;
k_med = defaultFieldValue('INPUT','k_medianFiltering',6);

y_t = real(y_t(:))';   % y_t real valued row vector

ymax = max(y_t);
ymin = min(y_t);
mPP_default = 0.7*(ymax-ymin);

% minPeakProminence = defaultFieldValue('INPUT','minPeakProminence',0.7); % 0.5--0.9
minPeakProminence = defaultFieldValue('INPUT','minPeakProminence',mPP_default); % 0.5--0.9


% Depsilon = INPUT.Depsilon;
% sampleType = 'uniform'; % sampleAlphaAxis.m
% sampleType = 'none';  % sampleAlphaAxis.m

% print flag
prfl = defaultFieldValue('INPUT','flag_print',1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% remove dc component

flag_dc = defaultFieldValue('INPUT','flag_dc',0);

if (flag_dc==0)
   y_t = y_t - sum(y_t)/length(y_t);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Estimation of the average heart rate 

if ~isfield(INPUT,'averageHeartRate')||isempty(INPUT.averageHeartRate)
   if prfl; fprintf(1,'Estimate Average Heart Rate \n'); end
   Input1.estimateAverageHeartRate.minPeakProminence = minPeakProminence; 
   alpha0til = estimateAverageHeartRate(y_t,Input1.estimateAverageHeartRate);
   if (alpha0til<0.5/fse)||(alpha0til>2/fse)
      if prfl; fprintf(1,'WARNING: Wrong estimate, Use default value \n'); end
      alpha0til = 1.1/fse;
   end
else
   % alpha0til = averageHeartRate = 1.1/fse
   alpha0til = INPUT.averageHeartRate; 
end

if prfl 
   format long 
   fprintf(1,'Average Heart Rate = %g \n',alpha0til);
   fprintf(1,'Average Heart Rate = %g [Hz] \n',alpha0til*fse);
   fprintf(1,'sampling frequency = %g [Hz] \n',fse);   
   fprintf(1,'LPF bandwidth = %g \n',Wlpf);   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = length(y_t);
if prfl 
    fprintf(1,'N = %g \n',N); 
    fprintf(1,'data-record length = %g [s] \n',N/fse); 
end

Tp = round(1/alpha0til);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% remove trend

flag_removeTrend = defaultFieldValue('INPUT','flag_removeTrend',0);

if (flag_removeTrend==1)
   fprintf(1,'remove trend (Tp) \n'); 
   Input1.removeTrend.method = 1; 
   Input1.removeTrend.m = Tp;
   y0_t = y_t;  % save y(t) with trend
   % remove trend from y(t)
   y_t = removeTrend(y0_t,Input1.removeTrend);
   % trend signal
   y_trend_t = y0_t - y_t;
else
   y0_t = [];
   y_trend_t = [];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% lag-product PSD in [nu_a,nu_b)
nu_a = defaultFieldValue('INPUT','nu_a',-5/Tp);
nu_b = defaultFieldValue('INPUT','nu_b',5/Tp);

% de-warping
% eps_dewarp = 'estLagProd';       % 'estLagProd' 'projLagProd' 'gradLagProd' 'estCDF' 'projCDF' 'gradCDF' 'estCharFunc' 'projCharFunc' 'gradCharFunc'
% warpingMethod = 13;          % SINC: 11=slow, 12=fast; 13=fast DFT: 21=slow, 22=fast
warpingMethod = 12;          % SINC: 11=slow, 12=fast; 13=fast DFT: 21=slow, 22=fast
% Depsilon = 600;
% K_basis = 10;                % 2*K_basis = number of basis functions
% clipType = 2; 

% CSA
Deltaf_small = defaultFieldValue('INPUT','Deltaf_small',0.1*Deltaf);
taumax_large = defaultFieldValue('INPUT','taumax_large',64*Tp);
taumax_large = min([taumax_large,N/2]); % to avoid aliasing in cycRSCP1 with smooth='frequency2'
% npalpha = defaultFieldValue('INPUT','npalpha',512); 
tau0 = defaultFieldValue('INPUT','tau0',0);               % Tau = (tau0-taumax:Deltatau:tau0+taumax)
taumax = defaultFieldValue('INPUT','taumax',3*Tp);        % Tau = (tau0-taumax:Deltatau:tau0+taumax)

% Zoom
% alpha_a = defaultFieldValue('INPUT','alpha_a',-4.5*alpha0til);
% alpha_b = defaultFieldValue('INPUT','alpha_b',4.5*alpha0til);
% alphaZoomOversamplingFactor = defaultFieldValue('INPUT','alphaZoomOversamplingFactor',1);
f_a = defaultFieldValue('INPUT','f_a',-0.001*fse);
f_b = defaultFieldValue('INPUT','f_b',0.001*fse);

% % estimation of d epsilon(t) / dt
% Delta = defaultFieldValue('INPUT','Delta',N/10);
% BwDerivative = defaultFieldValue('INPUT','BwDerivative',0.40);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Input1.AMTWACS_Estimation.Parameters.twoSteps_flag = 1;
Input1.AMTWACS_Estimation.Parameters.kr = 0.8;

% amplitude and angle demodulation of the Lag Product 
Input1.AMTWACS_Estimation.AMTWACS_AmplAngDemodZ.alpha0til = alpha0til;
Input1.AMTWACS_Estimation.AMTWACS_AmplAngDemodZ.Wlpf = Wlpf;
Input1.AMTWACS_Estimation.AMTWACS_AmplAngDemodZ.lineEstimationMethod = 1; % 1 = least square; 2 = ad hoc
Input1.AMTWACS_Estimation.AMTWACS_AmplAngDemodZ.func_AAD = 'LagProd';                  
Input1.AMTWACS_Estimation.AMTWACS_AmplAngDemodZ.u0 = 0; 

% PSD of the lag product
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.alpha0til = alpha0til;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.Deltaf = Deltaf_small;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.nu_a = nu_a;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.nu_b = nu_b;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.tau0 = tau0;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.taumax = taumax_large;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.k_med = k_med;
Input1.AMTWACS_Estimation.AMTWACS_funcAAD_PSD.Wlpf = Wlpf;

if prfl; fprintf(1,'%s %s \n','y(t): AMTWACS_Estimation   | ',datestr(now)); end 

OUTPUT.AMTWACS_Estimation.LagProd = AMTWACS_Estimation_00(y_t,y_t,Input1.AMTWACS_Estimation);
           
OUTPUT_AMTWACS_debug = AMTWACS_Estimation_debug_0(OUTPUT.AMTWACS_Estimation.LagProd);
format long
disp(OUTPUT_AMTWACS_debug.display);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

epsilon_est_t = OUTPUT.AMTWACS_Estimation.LagProd.epsilon_est_t;
a_est_t = OUTPUT.AMTWACS_Estimation.LagProd.a_est_t;

Input1.dewarping.epsilon_est_t = epsilon_est_t;
Input1.dewarping.a_est_t = a_est_t;
Input1.dewarping.method = warpingMethod;
% Input1.dewarping.D = Depsilon;

Dmax = max(abs(epsilon_est_t));
Dmax = min([Dmax,length(y_t)/2]);  % to avoid errors

Input1.dewarping.D = ceil(Dmax);
    
fprintf(1,'Dmax = %g \n',Dmax);
% fprintf(1,'dewarping.D = %g \n',Input1.dewarping.D);

if prfl; fprintf(1,'%s %s \n','y(t): dewarping            | ',datestr(now)); end 

x_t = dewarping_00(y_t,Input1.dewarping);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% alpha = estimated average heart rate

alpha0est = OUTPUT.AMTWACS_Estimation.LagProd.alpha0est;

Input1.cycRSCP1.alpha0 = alpha0est;
Input1.cycRSCP1.oc = -1;
Input1.cycRSCP1.Deltaf = Deltaf;
Input1.cycRSCP1.smooth = 'frequency2';
Input1.cycRSCP1.freq2SmoothMode = 'odd';   % 'odd' or 'even' for smooth=='frequency2'
Input1.cycRSCP1.tau0 = 0;
Input1.cycRSCP1.taumax = taumax;
Input1.cycRSCP1.medianMode = 0;
Input1.cycRSCP1.k_med = k_med;

if prfl; fprintf(1,'%s %s \n','x(t): cycRSCP1 (alpha = heart rate) | ',datestr(now)); end 

% OUTPUT.cycRSCP1_czt = cycRSCP1_czt(x_t,x_t,Input1.cycRSCP1_czt);

OUTPUT.x.cycRSCP1 = cycRSCP1_00(x_t,x_t,Input1.cycRSCP1);

% zoom in [f_a,f_b)
Input1.zoomAF.fInterval = [f_a,f_b];
Input1.zoomAF.Ztype = 'fAxis';
% zoom of monodimensional spectra = zoom of frequency axis
OUTPUT.x.cycRSCP1.Syxa = zoomAF(OUTPUT.x.cycRSCP1.Syxa,Input1.zoomAF);
% OUTPUT.x.cycRSCP1.Pyxa = zoomAF(OUTPUT.x.cycRSCP1.Pyxa,Input1.zoomAF);
OUTPUT.x.cycRSCP1.F1 = zoomAF(OUTPUT.x.cycRSCP1.F1,Input1.zoomAF);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% y(t): alpha = 0

if prfl; fprintf(1,'%s %s \n','y(t): cycRSCP1 (alpha = 0) | ',datestr(now)); end 

Input1.cycRSCP1.alpha0 = 0;
OUTPUT.y.stationary.cycRSCP1 = cycRSCP1_00(y_t,y_t,Input1.cycRSCP1);

% zoom in [f_a,f_b)
% zoom of monodimensional spectra = zoom of frequency axis
OUTPUT.y.stationary.cycRSCP1.Syxa = zoomAF(OUTPUT.y.stationary.cycRSCP1.Syxa,Input1.zoomAF);
% OUTPUT.y.stationary.cycRSCP1.Pyxa = zoomAF(OUTPUT.y.stationary.cycRSCP1.Pyxa,Input1.zoomAF);
OUTPUT.y.stationary.cycRSCP1.F1 = zoomAF(OUTPUT.y.stationary.cycRSCP1.F1,Input1.zoomAF);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% x(t): alpha = 0;

if prfl; fprintf(1,'%s %s \n','x(t): cycRSCP1 (alpha = 0) | ',datestr(now)); end 

Input1.cycRSCP1.alpha0 = 0;
OUTPUT.x.stationary.cycRSCP1 = cycRSCP1_00(x_t,x_t,Input1.cycRSCP1);

% zoom in [f_a,f_b)
% zoom of monodimensional spectra = zoom of frequency axis
OUTPUT.x.stationary.cycRSCP1.Syxa = zoomAF(OUTPUT.x.stationary.cycRSCP1.Syxa,Input1.zoomAF);
% OUTPUT.x.stationary.cycRSCP1.Pyxa = zoomAF(OUTPUT.x.stationary.cycRSCP1.Pyxa,Input1.zoomAF);
OUTPUT.x.stationary.cycRSCP1.F1 = zoomAF(OUTPUT.x.stationary.cycRSCP1.F1,Input1.zoomAF);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if prfl; fprintf(1,'%s %s \n','x(t): FourierSeries        | ',datestr(now)); end 

Input1.FourierSeries.period = 1/alpha0est;

% Fourier series of xp(t)
% The Fourier coefficients can be computed starting from x(t)
[Z,F] = FourierSeries(x_t,Input1.FourierSeries);

OUTPUT.x.FourierSeries.FourierCoefficients = Z;
OUTPUT.x.FourierSeries.Harmonics = F;

% periodic signal xp(t) [Napolitano 2022, Eq. (2.3)]
tt = 0:1:N-1;
xp_t = zeros(1,N);
for k = 1:length(F)
    xp_t = xp_t + Z(k)*exp(2j*pi*F(k)*tt);
end
xp_t = real(xp_t);  % remove possible small imaginary part

% residual zero-mean CS signal xr(t)
xr_t = x_t - xp_t;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OUTPUT.y.y_t = y_t;                          % y(t) (without trend)
OUTPUT.y.y0_t = y0_t;                        % y(t) (with trend)
OUTPUT.y.y_trend_t = y_trend_t;              % trend in y(t)
OUTPUT.y.epsilon_est_t = epsilon_est_t;      % epsilon(t)
% OUTPUT.y.Depsilon_est_t = Depsilon_est_t;    % d epsilon(t) / dt
% OUTPUT.y.heart_rate_t = heart_rate_t;        % heart rate
OUTPUT.y.a_est_t = a_est_t;                  % a(t)
OUTPUT.x.alpha0est = alpha0est;
OUTPUT.x.x_t = x_t;                          % x(t) underlying CS signal
OUTPUT.x.xp_t = xp_t;                        % xp(t)
OUTPUT.x.xr_t = xr_t;                        % xr(t)

OUTPUT.functionInfo = functionInfo;
% OUTPUT.reference = reference;
OUTPUT.InputParameters = INPUT;

return