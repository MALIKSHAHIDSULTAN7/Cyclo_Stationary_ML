
set parameters in the header of main_ECGanalysis.m

run main_ECGanalysis.m

run plot_ECGanalysis.m